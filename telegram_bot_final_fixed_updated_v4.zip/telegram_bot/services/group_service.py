from telethon import TelegramClient
from telethon.tl.functions.messages import GetDialogsRequest
from telethon.tl.types import InputPeerEmpty, Channel, Chat, User
from telethon.sessions import StringSession
import asyncio
import logging
from datetime import datetime
from database.db import Database
from config.config import API_ID, API_HASH

class GroupService:
    def __init__(self):
        self.db = Database()
        self.users_collection = self.db.get_collection('users')
        self.groups_collection = self.db.get_collection('groups')
        self.logger = logging.getLogger(__name__)
    
    async def fetch_user_groups(self, user_id):
        """
        Fetch all groups for a user (excluding channels)
        Returns:
            - (success, message, groups) tuple
        """
        try:
            # Get user session from database
            user = self.users_collection.find_one({'user_id': user_id})
            if not user or 'session_string' not in user:
                return (False, "لم يتم العثور على جلسة مستخدم. يرجى تسجيل الدخول أولاً.", [])
            
            session_string = user['session_string']
            
            # Create client with session string
            client = TelegramClient(StringSession(session_string), API_ID, API_HASH)
            await client.connect()
            
            # Check if session is valid
            if not await client.is_user_authorized():
                await client.disconnect()
                return (False, "جلسة غير صالحة. يرجى تسجيل الدخول مرة أخرى.", [])
            
            try:
                # Fetch dialogs with proper error handling
                result = await client(GetDialogsRequest(
                    offset_date=None,
                    offset_id=0,
                    offset_peer=InputPeerEmpty(),
                    limit=100,
                    hash=0
                ))
                
                # Filter groups only (exclude channels)
                groups = []
                
                # Get all chats from the result
                chats = result.chats
                
                # Create a dictionary to map chat IDs to chat entities
                chat_dict = {chat.id: chat for chat in chats}
                
                # Process dialogs and match with entities from chats
                for dialog in result.dialogs:
                    # Get the peer ID from the dialog
                    peer_id = dialog.peer.chat_id if hasattr(dialog.peer, 'chat_id') else (
                        dialog.peer.channel_id if hasattr(dialog.peer, 'channel_id') else None
                    )
                    
                    if peer_id and peer_id in chat_dict:
                        entity = chat_dict[peer_id]
                        
                        # Check if it's a group (megagroup for supergroups) - EXCLUDE regular channels
                        is_group = (isinstance(entity, Channel) and getattr(entity, 'megagroup', False)) or isinstance(entity, Chat)
                        
                        # Only include groups, not channels
                        if is_group:
                            group_info = {
                                'id': str(entity.id),  # تحويل معرف المجموعة إلى نص
                                'title': entity.title,
                                'username': getattr(entity, 'username', None),
                                'participants_count': getattr(entity, 'participants_count', 0),
                                'type': 'supergroup' if (isinstance(entity, Channel) and getattr(entity, 'megagroup', False)) else 'group'
                            }
                            groups.append(group_info)
                
                # Save groups to database
                self.save_user_groups(user_id, groups)
                
                await client.disconnect()
                return (True, f"تم جلب {len(groups)} مجموعة بنجاح.", groups)
            
            except Exception as e:
                await client.disconnect()
                self.logger.error(f"Error in GetDialogsRequest: {str(e)}")
                return (False, f"حدث خطأ أثناء جلب المجموعات: {str(e)}", [])
            
        except Exception as e:
            self.logger.error(f"Error in fetch_user_groups: {str(e)}")
            return (False, f"حدث خطأ أثناء جلب المجموعات: {str(e)}", [])
    
    def save_user_groups(self, user_id, groups):
        """
        Save user groups to database
        """
        # Get existing user groups
        user = self.users_collection.find_one({'user_id': user_id})
        if not user:
            return False
        
        # Get blacklisted groups
        blacklisted_groups = user.get('blacklisted_groups', [])
        
        # Update user with timestamp only - don't try to store groups in users table
        self.users_collection.update_one(
            {'user_id': user_id},
            {'$set': {
                'updated_at': datetime.now()
            }}
        )
        
        # Save detailed group info - only using columns that exist in the database schema
        for group in groups:
            # تصحيح: تحويل معرف المجموعة إلى نص لضمان الاتساق
            group_id = str(group['id'])
            
            # First check if the group exists in the database
            existing_group = self.groups_collection.find_one({
                'group_id': group_id, 
                'user_id': user_id
            })
            
            # Determine if the group is blacklisted
            is_blacklisted = False
            if existing_group and 'blacklisted' in existing_group:
                is_blacklisted = existing_group['blacklisted']
            elif group_id in [str(g) for g in blacklisted_groups]:
                is_blacklisted = True
                
            # Update or insert the group - only using fields that exist in the database schema
            self.groups_collection.update_one(
                {'group_id': group_id, 'user_id': user_id},
                {'$set': {
                    'title': group['title'],
                    'blacklisted': is_blacklisted,
                    'updated_at': datetime.now()
                }},
                upsert=True
            )
        
        return True
    
    def get_user_groups(self, user_id):
        """
        Get user groups from database
        Returns:
            - list of groups
        """
        groups = self.groups_collection.find({'user_id': user_id})
        return list(groups)
    
    def get_user_active_groups(self, user_id):
        """
        Get user active groups (not blacklisted) from database
        Returns:
            - list of groups
        """
        groups = self.groups_collection.find({
            'user_id': user_id,
            'blacklisted': False
        })
        return list(groups)
    
    def toggle_group_blacklist(self, user_id, group_id):
        """
        Toggle group blacklist status
        Returns:
            - (success, is_blacklisted) tuple
        """
        try:
            # تصحيح: تحويل معرف المجموعة إلى نص لضمان الاتساق
            group_id = str(group_id)
            
            # Get group
            group = self.groups_collection.find_one({
                'group_id': group_id,
                'user_id': user_id
            })
            
            if not group:
                return (False, False)
            
            # Toggle blacklist status
            is_blacklisted = not group.get('blacklisted', False)
            
            # Update group
            self.groups_collection.update_one(
                {'group_id': group_id, 'user_id': user_id},
                {'$set': {
                    'blacklisted': is_blacklisted,
                    'updated_at': datetime.now()
                }}
            )
            
            # Update user's blacklisted_groups list if it exists
            if is_blacklisted:
                self.users_collection.update_one(
                    {'user_id': user_id},
                    {'$addToSet': {'blacklisted_groups': group_id}}
                )
            else:
                self.users_collection.update_one(
                    {'user_id': user_id},
                    {'$pull': {'blacklisted_groups': group_id}}
                )
            
            return (True, is_blacklisted)
            
        except Exception as e:
            self.logger.error(f"Error in toggle_group_blacklist: {str(e)}")
            return (False, False)
