import os
import json
import logging
import threading
import asyncio
import time
from datetime import datetime, timedelta
from telethon import TelegramClient
from telethon.sessions import StringSession
from telethon.tl.functions.messages import SendMessageRequest
from telethon.tl.types import InputPeerChannel, InputPeerChat, InputPeerUser
from config.config import API_ID, API_HASH
from database.db import Database
from utils.channel_subscription import channel_subscription

class PostingService:
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super(PostingService, cls).__new__(cls)
                cls._instance.initialize()
        return cls._instance
    
    def initialize(self):
        """Initialize the posting service"""
        self.db = Database()
        self.users_collection = self.db.get_collection('users')
        self.groups_collection = self.db.get_collection('groups')
        self.posts_collection = self.db.get_collection('posts')
        self.messages_collection = self.db.get_collection('messages')
        
        # Set up logging
        self.logger = logging.getLogger(__name__)
        
        # Active posting tasks
        self.active_tasks = {}
        
        # Persistence file for active tasks
        self.persistence_file = 'data/active_posting_tasks.json'
        
        # Add lock for thread synchronization
        self.tasks_lock = threading.Lock()
        
        # Ensure data directory exists
        os.makedirs('data', exist_ok=True)
        
        # تصحيح: إضافة علم للإشارة إلى أن الخدمة قيد التشغيل
        self.is_running = True
        
        # Restore active tasks from file
        self.restore_active_tasks()
        
        # Check database schema
        self.check_database_schema()
        
        # تصحيح: إضافة مؤقت لحفظ المهام النشطة بشكل دوري
        self.start_auto_save_timer()
        
        # إضافة مؤقت لتحديث الحالة تلقائياً كل دقيقة
        self.start_auto_status_update_timer()
    
    def start_auto_save_timer(self):
        """بدء مؤقت لحفظ المهام النشطة بشكل دوري"""
        def auto_save():
            while self.is_running:
                try:
                    # حفظ المهام النشطة كل 60 ثانية
                    self.save_active_tasks()
                    self.logger.info("Auto-saved active tasks")
                except Exception as e:
                    self.logger.error(f"Error in auto-save: {str(e)}")
                
                # انتظار 60 ثانية
                time.sleep(60)
        
        # بدء مؤقت الحفظ التلقائي في خيط منفصل
        threading.Thread(target=auto_save, daemon=True).start()
    
    def start_auto_status_update_timer(self):
        """بدء مؤقت لتحديث حالة النشر تلقائياً كل دقيقة"""
        def auto_status_update():
            while self.is_running:
                try:
                    # تحديث حالة جميع المهام النشطة
                    with self.tasks_lock:
                        for task_id, task_data in list(self.active_tasks.items()):
                            if task_data['status'] == 'running':
                                # تحديث وقت آخر نشاط
                                task_data['last_activity'] = datetime.now()
                                
                                # إرسال تحديث الحالة (سيتم تنفيذه في الخيط الرئيسي)
                                self.logger.info(f"Auto-updating status for task {task_id}")
                                
                                # تحديث حالة المهمة في قاعدة البيانات
                                self.update_task_status(task_id, task_data)
                except Exception as e:
                    self.logger.error(f"Error in auto-status update: {str(e)}")
                
                # انتظار 60 ثانية
                time.sleep(60)
        
        # بدء مؤقت تحديث الحالة التلقائي في خيط منفصل
        threading.Thread(target=auto_status_update, daemon=True).start()
    
    def update_task_status(self, task_id, task_data):
        """تحديث حالة المهمة في قاعدة البيانات"""
        try:
            # تصحيح: استخدام اتصال جديد لقاعدة البيانات لتجنب مشكلة "Recursive use of cursors"
            db = Database()
            cursor = db.cursor
            conn = db.conn
            
            # تحديث حالة المهمة في جدول active_tasks
            cursor.execute("""
                UPDATE active_tasks 
                SET last_activity = ?, message_count = ?
                WHERE task_id = ?
            """, (
                datetime.now().isoformat(),
                task_data.get('message_count', 0),
                task_id
            ))
            
            # حفظ التغييرات
            conn.commit()
            
            self.logger.info(f"Updated status for task {task_id}")
        except Exception as e:
            self.logger.error(f"Error updating task status: {str(e)}")
    
    def check_database_schema(self):
        """Check and update database schema if needed"""
        try:
            # Use the database connection directly from the db object
            cursor = self.db.cursor
            conn = self.db.conn
            
            # Check if posts table exists
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='posts'")
            if not cursor.fetchone():
                # Create posts table
                self.logger.info("Creating posts table")
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS posts (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER,
                        message TEXT,
                        group_ids TEXT,
                        delay_seconds INTEGER DEFAULT 0,
                        exact_time TEXT,
                        status TEXT DEFAULT 'pending',
                        created_at TEXT,
                        updated_at TEXT,
                        FOREIGN KEY (user_id) REFERENCES users (user_id) ON DELETE CASCADE
                    )
                ''')
                conn.commit()
            else:
                # Check if exact_time column exists
                try:
                    cursor.execute("SELECT exact_time FROM posts LIMIT 1")
                except Exception:
                    # Add exact_time column
                    try:
                        self.logger.info("Adding exact_time column to posts table")
                        cursor.execute("ALTER TABLE posts ADD COLUMN exact_time TEXT")
                        conn.commit()
                    except Exception as e:
                        self.logger.warning(f"Could not add exact_time column: {str(e)}")
            
            # Check if messages table exists
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='messages'")
            if not cursor.fetchone():
                # Create messages table
                self.logger.info("Creating messages table")
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS messages (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER,
                        post_id INTEGER,
                        group_id TEXT,
                        message_id INTEGER,
                        timestamp TEXT,
                        FOREIGN KEY (user_id) REFERENCES users (user_id) ON DELETE CASCADE,
                        FOREIGN KEY (post_id) REFERENCES posts (id) ON DELETE CASCADE
                    )
                ''')
                conn.commit()
            
            # تصحيح: إضافة جدول للمهام النشطة للاستمرارية
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='active_tasks'")
            if not cursor.fetchone():
                # إنشاء جدول المهام النشطة
                self.logger.info("Creating active_tasks table")
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS active_tasks (
                        task_id TEXT PRIMARY KEY,
                        user_id INTEGER,
                        post_id INTEGER,
                        message TEXT,
                        group_ids TEXT,
                        delay_seconds INTEGER DEFAULT 0,
                        exact_time TEXT,
                        status TEXT DEFAULT 'running',
                        start_time TEXT,
                        last_activity TEXT,
                        message_count INTEGER DEFAULT 0,
                        message_id INTEGER,
                        is_recurring INTEGER DEFAULT 1,
                        FOREIGN KEY (user_id) REFERENCES users (user_id) ON DELETE CASCADE,
                        FOREIGN KEY (post_id) REFERENCES posts (id) ON DELETE CASCADE
                    )
                ''')
                conn.commit()
            
            # إضافة جدول لتحديثات الحالة
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='status_updates'")
            if not cursor.fetchone():
                # إنشاء جدول تحديثات الحالة
                self.logger.info("Creating status_updates table")
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS status_updates (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        task_id TEXT,
                        user_id INTEGER,
                        message_count INTEGER DEFAULT 0,
                        timestamp TEXT,
                        FOREIGN KEY (task_id) REFERENCES active_tasks (task_id) ON DELETE CASCADE,
                        FOREIGN KEY (user_id) REFERENCES users (user_id) ON DELETE CASCADE
                    )
                ''')
                conn.commit()
            
            self.logger.info("Database schema check completed")
        except Exception as e:
            self.logger.error(f"Error checking database schema: {str(e)}")
    
    def restore_active_tasks(self):
        """Restore active posting tasks from file for continuity"""
        try:
            # تصحيح: استعادة المهام النشطة من قاعدة البيانات أولاً
            self.restore_active_tasks_from_db()
            
            # ثم استعادة المهام من الملف كاحتياط
            if os.path.exists(self.persistence_file):
                with open(self.persistence_file, 'r', encoding='utf-8') as f:
                    tasks_data = json.load(f)
                
                # Restore tasks
                restored_count = 0
                with self.tasks_lock:
                    for task_id, task_data in tasks_data.items():
                        # تخطي المهام الموجودة بالفعل (تم استعادتها من قاعدة البيانات)
                        if task_id in self.active_tasks:
                            continue
                        
                        # Convert string timestamps to datetime objects
                        try:
                            task_data['start_time'] = datetime.fromisoformat(task_data['start_time'])
                            task_data['last_activity'] = datetime.fromisoformat(task_data['last_activity'])
                        except:
                            task_data['start_time'] = datetime.now()
                            task_data['last_activity'] = datetime.now()
                        
                        # Add task to active tasks
                        self.active_tasks[task_id] = task_data
                        restored_count += 1
                
                self.logger.info(f"Found {restored_count} additional active posting tasks in file")
                
                # Restart any running tasks
                self.restart_active_tasks()
                
                self.logger.info(f"Restored {restored_count} additional active posting tasks from file")
        except Exception as e:
            self.logger.error(f"Error restoring active tasks from file: {str(e)}")
    
    def restore_active_tasks_from_db(self):
        """استعادة المهام النشطة من قاعدة البيانات"""
        try:
            cursor = self.db.cursor
            
            # استعلام عن المهام النشطة
            cursor.execute("SELECT * FROM active_tasks WHERE status = 'running'")
            tasks = cursor.fetchall()
            
            # استعادة المهام
            restored_count = 0
            with self.tasks_lock:
                for task in tasks:
                    task_id = task[0]
                    
                    # تحويل البيانات إلى قاموس
                    task_data = {
                        'user_id': task[1],
                        'post_id': task[2],
                        'message': task[3],
                        'group_ids': json.loads(task[4]) if task[4] else [],
                        'delay_seconds': task[5],
                        'exact_time': task[6],
                        'status': task[7],
                        'start_time': datetime.fromisoformat(task[8]) if task[8] else datetime.now(),
                        'last_activity': datetime.fromisoformat(task[9]) if task[9] else datetime.now(),
                        'message_count': task[10] or 0,
                        'message_id': task[11],
                        'is_recurring': bool(task[12])
                    }
                    
                    # إضافة المهمة إلى المهام النشطة
                    self.active_tasks[task_id] = task_data
                    restored_count += 1
            
            self.logger.info(f"Found {restored_count} active posting tasks in database")
            
            # إعادة تشغيل المهام النشطة
            self.restart_active_tasks()
            
            self.logger.info(f"Restored {restored_count} active posting tasks from database")
        except Exception as e:
            self.logger.error(f"Error restoring active tasks from database: {str(e)}")
    
    def restart_active_tasks(self):
        """إعادة تشغيل المهام النشطة"""
        try:
            # إعادة تشغيل أي مهام نشطة
            for task_id, task_data in list(self.active_tasks.items()):
                if task_data['status'] == 'running':
                    threading.Thread(target=self.start_posting_task, args=(task_id,)).start()
                    self.logger.info(f"Restarted posting task {task_id}")
        except Exception as e:
            self.logger.error(f"Error restarting active tasks: {str(e)}")
    
    def save_active_tasks(self):
        """Save active posting tasks to file for continuity"""
        try:
            # Create data directory if it doesn't exist
            os.makedirs('data', exist_ok=True)
            
            # Convert datetime objects to strings
            tasks_data = {}
            with self.tasks_lock:
                for task_id, task_data in self.active_tasks.items():
                    tasks_data[task_id] = task_data.copy()
                    tasks_data[task_id]['start_time'] = task_data['start_time'].isoformat()
                    tasks_data[task_id]['last_activity'] = task_data['last_activity'].isoformat()
            
            # Save tasks to file
            with open(self.persistence_file, 'w', encoding='utf-8') as f:
                json.dump(tasks_data, f, ensure_ascii=False, indent=2)
            
            # تصحيح: حفظ المهام النشطة في قاعدة البيانات أيضاً
            self.save_active_tasks_to_db()
            
            self.logger.info(f"Saved {len(tasks_data)} active posting tasks")
        except Exception as e:
            self.logger.error(f"Error saving active tasks: {str(e)}")
    
    def save_active_tasks_to_db(self):
        """حفظ المهام النشطة في قاعدة البيانات"""
        try:
            # تصحيح: استخدام اتصال جديد لقاعدة البيانات لتجنب مشكلة "Recursive use of cursors"
            db = Database()
            cursor = db.cursor
            conn = db.conn
            
            # حذف جميع المهام السابقة
            cursor.execute("DELETE FROM active_tasks")
            
            # حفظ المهام النشطة
            with self.tasks_lock:
                for task_id, task_data in self.active_tasks.items():
                    # تحويل group_ids إلى JSON
                    group_ids_json = json.dumps(task_data['group_ids'])
                    
                    # تحويل التواريخ إلى نصوص
                    start_time = task_data['start_time'].isoformat()
                    last_activity = task_data['last_activity'].isoformat()
                    
                    # تحويل is_recurring إلى رقم
                    is_recurring = 1 if task_data.get('is_recurring', True) else 0
                    
                    # إدراج المهمة في قاعدة البيانات
                    cursor.execute('''
                        INSERT INTO active_tasks (
                            task_id, user_id, post_id, message, group_ids, delay_seconds, exact_time, 
                            status, start_time, last_activity, message_count, message_id, is_recurring
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (
                        task_id,
                        task_data['user_id'],
                        task_data['post_id'],
                        task_data['message'],
                        group_ids_json,
                        task_data['delay_seconds'],
                        task_data.get('exact_time', ''),
                        task_data['status'],
                        start_time,
                        last_activity,
                        task_data.get('message_count', 0),
                        task_data.get('message_id'),
                        is_recurring
                    ))
            
            # حفظ التغييرات
            conn.commit()
            
            self.logger.info(f"Saved {len(self.active_tasks)} active posting tasks to database")
        except Exception as e:
            self.logger.error(f"Error saving active tasks to database: {str(e)}")
            
    def get_user_groups(self, user_id):
        """
        الحصول على مجموعات المستخدم من قاعدة البيانات
        Returns:
            - قائمة بالمجموعات
        """
        try:
            groups = self.groups_collection.find({'user_id': user_id})
            return list(groups)
        except Exception as e:
            self.logger.error(f"Error getting user groups: {str(e)}")
            return []
    
    def add_status_update(self, task_id, user_id, message_count):
        """إضافة تحديث حالة جديد"""
        try:
            # تصحيح: استخدام اتصال جديد لقاعدة البيانات لتجنب مشكلة "Recursive use of cursors"
            db = Database()
            cursor = db.cursor
            conn = db.conn
            
            # إضافة تحديث حالة جديد
            cursor.execute('''
                INSERT INTO status_updates (
                    task_id, user_id, message_count, timestamp
                ) VALUES (?, ?, ?, ?)
            ''', (
                task_id,
                user_id,
                message_count,
                datetime.now().isoformat()
            ))
            
            # حفظ التغييرات
            conn.commit()
            
            self.logger.info(f"Added status update for task {task_id}")
        except Exception as e:
            self.logger.error(f"Error adding status update: {str(e)}")
    
    async def post_message(self, user_id, message, group_ids, delay_seconds=0, exact_time=None, message_id=None):
        """Start posting a message to multiple groups"""
        try:
            # Get user session
            user = self.users_collection.find_one({'user_id': user_id})
            if not user or 'session_string' not in user:
                return (False, "لم يتم العثور على جلسة المستخدم. يرجى تسجيل الدخول أولاً.")
            
            # Create post record
            post_id = f"post_{user_id}_{int(datetime.now().timestamp())}"
            
            # Ensure correct data types
            try:
                user_id = int(user_id)
                delay_seconds = int(delay_seconds) if delay_seconds is not None else 0
            except (ValueError, TypeError):
                self.logger.error(f"Invalid data types: user_id={user_id}, delay_seconds={delay_seconds}")
                return (False, "قيم غير صالحة. يرجى المحاولة مرة أخرى.")
            
            # تحويل جميع معرفات المجموعات إلى نصوص لضمان الاتساق
            group_ids = [str(group_id) for group_id in group_ids]
            
            # Create task data
            task_id = f"task_{user_id}_{int(datetime.now().timestamp())}"
            task_data = {
                'user_id': user_id,
                'post_id': post_id,
                'message': message,
                'group_ids': group_ids,
                'delay_seconds': delay_seconds,
                'exact_time': exact_time,
                'status': 'running',
                'start_time': datetime.now(),
                'last_activity': datetime.now(),
                'message_count': 0,
                'message_id': message_id
            }
            
            # Add task to active tasks
            with self.tasks_lock:
                self.active_tasks[task_id] = task_data
            
            # Save active tasks
            self.save_active_tasks()
            
            # Start posting task in a separate thread
            threading.Thread(target=self.start_posting_task, args=(task_id,)).start()
            
            # إضافة تحديث حالة أولي
            self.add_status_update(task_id, user_id, 0)
            
            # Return success
            if exact_time:
                return (True, f"تم جدولة النشر في {len(group_ids)} مجموعة في الساعة {exact_time}.")
            else:
                return (True, f"تم بدء النشر في {len(group_ids)} مجموعة.")
        except Exception as e:
            self.logger.error(f"Error starting posting: {str(e)}")
            return (False, f"حدث خطأ أثناء بدء النشر: {str(e)}")
    
    async def send_message_to_group(self, client, entity, message, task_id, user_id, post_id, group_id):
        """إرسال رسالة إلى مجموعة واحدة بشكل متزامن"""
        try:
            # إرسال الرسالة باستخدام الكيان المباشر
            sent_message = await client.send_message(entity, message)
            
            # حفظ الرسالة في قاعدة البيانات
            self.messages_collection.insert_one({
                'user_id': user_id,
                'post_id': post_id,
                'group_id': group_id,
                'message_id': sent_message.id,
                'timestamp': datetime.now()
            })
            
            return True
        except Exception as e:
            self.logger.error(f"Error sending message to group {group_id}: {str(e)}")
            return False
    
    async def send_messages_concurrently(self, client, dialog_dict, group_ids, group_dict, message, task_id, user_id, post_id):
        """إرسال رسائل إلى جميع المجموعات بشكل متزامن"""
        tasks = []
        for group_id in group_ids:
            try:
                # تحويل معرف المجموعة إلى نص لضمان الاتساق
                group_id = str(group_id)
                
                # Check if task is still running
                with self.tasks_lock:
                    if task_id not in self.active_tasks or self.active_tasks[task_id]['status'] != 'running':
                        self.logger.info(f"Task {task_id} stopped")
                        break
                
                # تصحيح: التحقق من أن المجموعة موجودة في قاعدة البيانات وليست في القائمة السوداء
                if group_id not in group_dict:
                    self.logger.warning(f"Group {group_id} not found in database for user {user_id}")
                    continue
                
                group_info = group_dict[group_id]
                if group_info.get('blacklisted', False):
                    self.logger.info(f"Skipping blacklisted group {group_id}")
                    continue
                
                # نهج جديد: البحث عن الدردشة في قاموس الدردشات
                if group_id in dialog_dict:
                    entity = dialog_dict[group_id]
                    self.logger.info(f"Found entity for group {group_id} in dialogs")
                    
                    # إضافة مهمة إرسال الرسالة إلى قائمة المهام
                    task = self.send_message_to_group(client, entity, message, task_id, user_id, post_id, group_id)
                    tasks.append(task)
                else:
                    # إذا لم يتم العثور على الدردشة في قاموس الدردشات، حاول استخدام اسم المستخدم إذا كان متاحاً
                    username = group_info.get('username')
                    if username:
                        try:
                            # إضافة مهمة إرسال الرسالة باستخدام اسم المستخدم إلى قائمة المهام
                            task = self.send_message_to_group(client, username, message, task_id, user_id, post_id, group_id)
                            tasks.append(task)
                        except Exception as e:
                            self.logger.error(f"Error creating task for group {group_id} by username {username}: {str(e)}")
                    else:
                        self.logger.warning(f"Group {group_id} not found in dialogs and has no username")
            except Exception as e:
                self.logger.error(f"Error processing group {group_id}: {str(e)}")
                continue
        
        # تنفيذ جميع المهام بشكل متزامن
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # حساب عدد الرسائل المرسلة بنجاح
        message_count = sum(1 for result in results if result is True)
        
        return message_count
    
    def start_posting_task(self, task_id):
        """Start posting task"""
        try:
            # Get task data
            with self.tasks_lock:
                if task_id not in self.active_tasks:
                    self.logger.error(f"Task {task_id} not found in active tasks")
                    return
                
                task_data = self.active_tasks[task_id]
            
            # Get task parameters
            user_id = task_data['user_id']
            message = task_data['message']
            group_ids = task_data['group_ids']
            delay_seconds = task_data['delay_seconds']
            exact_time = task_data['exact_time']
            post_id = task_data['post_id']
            
            # Get user session
            user = self.users_collection.find_one({'user_id': user_id})
            if not user or 'session_string' not in user:
                self.logger.error(f"User session not found for user {user_id}")
                with self.tasks_lock:
                    if task_id in self.active_tasks:
                        self.active_tasks[task_id]['status'] = 'error'
                        self.active_tasks[task_id]['error'] = "لم يتم العثور على جلسة المستخدم."
                return
            
            session_string = user['session_string']
            
            # If exact time is specified, wait until that time
            if exact_time:
                try:
                    # Parse exact time
                    hour, minute = map(int, exact_time.split(':'))
                    
                    # Get current time
                    now = datetime.now()
                    
                    # Create target time
                    target_time = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
                    
                    # If target time is in the past, add one day
                    if target_time < now:
                        target_time += timedelta(days=1)
                    
                    # Calculate wait time
                    wait_seconds = (target_time - now).total_seconds()
                    
                    # Wait until target time
                    self.logger.info(f"Waiting {wait_seconds} seconds until {target_time} for task {task_id}")
                    time.sleep(wait_seconds)
                except Exception as e:
                    self.logger.error(f"Error parsing exact time: {str(e)}")
                    with self.tasks_lock:
                        if task_id in self.active_tasks:
                            self.active_tasks[task_id]['status'] = 'error'
                            self.active_tasks[task_id]['error'] = f"خطأ في تنسيق الوقت المحدد: {str(e)}"
                    return
            
            # تصحيح: الحصول على معلومات المجموعات من قاعدة البيانات
            db_groups = self.get_user_active_groups(user_id)
            
            # تحويل قائمة المجموعات إلى قاموس للبحث السريع
            group_dict = {str(group.get('group_id')): group for group in db_groups}
            
            # Create event loop for async operations
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            
            # Create client with session string
            client = TelegramClient(StringSession(session_string), API_ID, API_HASH, loop=loop)
            
            # Connect to Telegram
            loop.run_until_complete(client.connect())
            
            # Check if session is valid
            if not loop.run_until_complete(client.is_user_authorized()):
                self.logger.error(f"Invalid session for user {user_id}")
                with self.tasks_lock:
                    if task_id in self.active_tasks:
                        self.active_tasks[task_id]['status'] = 'error'
                        self.active_tasks[task_id]['error'] = "جلسة غير صالحة. يرجى تسجيل الدخول مرة أخرى."
                loop.run_until_complete(client.disconnect())
                return
            
            # نهج جديد: استخدام الطريقة المباشرة للنشر في المجموعات
            # الحصول على جميع الدردشات المتاحة أولاً
            dialogs = loop.run_until_complete(client.get_dialogs())
            
            # إنشاء قاموس للبحث السريع عن الدردشات حسب المعرف
            dialog_dict = {}
            for dialog in dialogs:
                # الحصول على معرف الدردشة
                if hasattr(dialog.entity, 'id'):
                    dialog_dict[str(dialog.entity.id)] = dialog.entity
            
            # تنفيذ النشر المتزامن لجميع المجموعات
            message_count = loop.run_until_complete(
                self.send_messages_concurrently(
                    client, dialog_dict, group_ids, group_dict, message, task_id, user_id, post_id
                )
            )
            
            # تحديث عداد الرسائل في المهمة
            with self.tasks_lock:
                if task_id in self.active_tasks:
                    self.active_tasks[task_id]['message_count'] = message_count
                    self.active_tasks[task_id]['last_activity'] = datetime.now()
            
            # إضافة تحديث حالة
            self.add_status_update(task_id, user_id, message_count)
            
            # Disconnect from Telegram
            loop.run_until_complete(client.disconnect())
            
            # Update task status
            with self.tasks_lock:
                if task_id in self.active_tasks:
                    self.active_tasks[task_id]['status'] = 'completed'
                    self.active_tasks[task_id]['message_count'] = message_count
                    self.active_tasks[task_id]['last_activity'] = datetime.now()
            
            # Save active tasks
            self.save_active_tasks()
            
            # إضافة تحديث حالة نهائي
            self.add_status_update(task_id, user_id, message_count)
            
            self.logger.info(f"Task {task_id} completed. Posted {message_count} messages concurrently.")
        except Exception as e:
            self.logger.error(f"Error in posting task {task_id}: {str(e)}")
            with self.tasks_lock:
                if task_id in self.active_tasks:
                    self.active_tasks[task_id]['status'] = 'error'
                    self.active_tasks[task_id]['error'] = str(e)
            
            # Save active tasks
            self.save_active_tasks()
    
    def get_user_active_groups(self, user_id):
        """
        Get user active groups (not blacklisted) from database
        Returns:
            - list of groups
        """
        groups = self.groups_collection.find({
            'user_id': user_id,
            'blacklisted': False
        })
        return list(groups)
    
    def get_posting_status(self, user_id):
        """Get posting status for a user"""
        try:
            # Get active tasks for user
            active_tasks = []
            with self.tasks_lock:
                for task_id, task_data in self.active_tasks.items():
                    if task_data['user_id'] == user_id and task_data['status'] == 'running':
                        # Add task to active tasks
                        active_tasks.append({
                            'task_id': task_id,
                            'message': task_data['message'],
                            'group_count': len(task_data['group_ids']),
                            'delay_seconds': task_data['delay_seconds'],
                            'exact_time': task_data.get('exact_time'),
                            'start_time': task_data['start_time'].strftime('%Y-%m-%d %H:%M:%S'),
                            'message_count': task_data.get('message_count', 0),
                            'status': task_data['status']
                        })
            
            # Return status
            return {
                'is_active': len(active_tasks) > 0,
                'active_tasks': active_tasks
            }
        except Exception as e:
            self.logger.error(f"Error getting posting status: {str(e)}")
            return {
                'is_active': False,
                'active_tasks': []
            }
    
    def stop_posting(self, user_id):
        """Stop posting for a user"""
        try:
            # Get active tasks for user
            stopped_count = 0
            with self.tasks_lock:
                for task_id, task_data in list(self.active_tasks.items()):
                    if task_data['user_id'] == user_id and task_data['status'] == 'running':
                        # Stop task
                        self.active_tasks[task_id]['status'] = 'stopped'
                        stopped_count += 1
            
            # Save active tasks
            self.save_active_tasks()
            
            # Return result
            if stopped_count > 0:
                return (True, f"تم إيقاف {stopped_count} مهمة نشر.")
            else:
                return (False, "لا توجد مهام نشر نشطة.")
        except Exception as e:
            self.logger.error(f"Error stopping posting: {str(e)}")
            return (False, f"حدث خطأ أثناء إيقاف النشر: {str(e)}")
    
    def get_active_posting_tasks(self, user_id):
        """Get active posting tasks for a user"""
        try:
            # Get active tasks for user
            active_tasks = []
            with self.tasks_lock:
                for task_id, task_data in self.active_tasks.items():
                    if task_data['user_id'] == user_id and task_data['status'] == 'running':
                        # Add task to active tasks
                        active_tasks.append({
                            'task_id': task_id,
                            'message': task_data['message'],
                            'group_ids': task_data['group_ids'],
                            'delay_seconds': task_data['delay_seconds'],
                            'exact_time': task_data.get('exact_time'),
                            'start_time': task_data['start_time'],
                            'message_count': task_data.get('message_count', 0),
                            'status': task_data['status']
                        })
            
            # Return active tasks
            return active_tasks
        except Exception as e:
            self.logger.error(f"Error getting active posting tasks: {str(e)}")
            return []
