from functools import wraps
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import CallbackContext
import re
import logging

# إعداد التسجيل
logger = logging.getLogger(__name__)

class ChannelSubscription:
    def __init__(self):
        self.required_channel = None
    
    def set_required_channel(self, channel_username):
        """Set the channel username that users must subscribe to"""
        # Ensure channel username starts with @
        if not channel_username.startswith('@'):
            channel_username = f"@{channel_username}"
        
        # Validate username format
        if not self._is_valid_username(channel_username):
            raise ValueError("معرف القناة غير صالح. يجب أن يبدأ بـ @ ويتكون من أحرف وأرقام وشرطات سفلية فقط.")
        
        self.required_channel = channel_username
        logger.info(f"تم تعيين القناة المطلوبة للاشتراك: {channel_username}")
    
    def _is_valid_username(self, username):
        """Check if username is in valid Telegram format"""
        # Telegram usernames must start with @ and contain only letters, numbers, and underscores
        # Minimum length is 5 characters (@ + at least 4 characters)
        pattern = r'^@[a-zA-Z0-9_]{4,}$'
        return bool(re.match(pattern, username))
    
    def get_required_channel(self):
        """Get the required channel username"""
        return self.required_channel
    
    async def check_user_subscription(self, bot, user_id):
        """Check if user is subscribed to the required channel"""
        if not self.required_channel:
            return True, None  # No channel requirement
        
        try:
            # Try to get chat member info
            chat_member = await bot.get_chat_member(chat_id=self.required_channel, user_id=user_id)
            
            # Check if user is a member
            if chat_member.status in ['member', 'administrator', 'creator']:
                return True, None  # User is subscribed
            else:
                return False, self.required_channel  # User is not subscribed
        except Exception as e:
            logger.error(f"خطأ في التحقق من اشتراك المستخدم {user_id} في القناة {self.required_channel}: {str(e)}")
            return False, self.required_channel  # Error checking subscription, assume not subscribed
    
    async def check_bot_is_admin(self, bot):
        """Check if the bot is an admin in the required channel"""
        if not self.required_channel:
            return False, "لم يتم تعيين قناة للاشتراك الإجباري بعد."
        
        try:
            # Get bot's ID
            bot_info = await bot.get_me()
            bot_id = bot_info.id
            
            # Check if bot is admin in the channel
            chat_member = await bot.get_chat_member(chat_id=self.required_channel, user_id=bot_id)
            
            # Check if bot is an administrator
            if chat_member.status in ['administrator', 'creator']:
                return True, None
            else:
                return False, f"البوت ليس مشرفًا في القناة {self.required_channel}. يجب ترقية البوت إلى مشرف في القناة أولاً."
        except Exception as e:
            logger.error(f"خطأ في التحقق من صلاحيات البوت في القناة {self.required_channel}: {str(e)}")
            return False, f"حدث خطأ أثناء التحقق من صلاحيات البوت: {str(e)}"

# Create a global instance
channel_subscription = ChannelSubscription()

def auto_channel_subscription_required(func):
    """Decorator to automatically check if user is subscribed to the required channel"""
    @wraps(func)
    async def wrapped(self, update: Update, context: CallbackContext, *args, **kwargs):
        user_id = update.effective_user.id
        
        # Get user from subscription service if available
        user = None
        if hasattr(self, 'subscription_service'):
            user = self.subscription_service.get_user(user_id)
        
        # If user is admin, bypass channel subscription check
        if user and hasattr(user, 'is_admin') and user.is_admin:
            return await func(self, update, context, *args, **kwargs)
        
        # Check if user is subscribed to the channel
        is_subscribed, required_channel = await channel_subscription.check_user_subscription(context.bot, user_id)
        
        if is_subscribed:
            # User is subscribed, proceed
            return await func(self, update, context, *args, **kwargs)
        
        # User is not subscribed, show subscription message
        keyboard = [
            [InlineKeyboardButton("✅ اشترك في القناة", url=f"https://t.me/{required_channel[1:]}")],
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.effective_chat.send_message(
            text=f"⚠️ يجب عليك الاشتراك في القناة {required_channel} للاستمرار في استخدام البوت.",
            reply_markup=reply_markup
        )
        return None
    
    return wrapped
