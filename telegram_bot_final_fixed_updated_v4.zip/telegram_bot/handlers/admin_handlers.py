from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import CallbackContext, CommandHandler, CallbackQueryHandler, MessageHandler, filters
from services.subscription_service import SubscriptionService
from utils.decorators import admin_required
import re
from datetime import datetime, timedelta

class AdminHandlers:
    def __init__(self, dispatcher):
        self.dispatcher = dispatcher
        self.subscription_service = SubscriptionService()
        
        # Register handlers
        self.register_handlers()
    
    def register_handlers(self):
        # Admin commands
        self.dispatcher.add_handler(CommandHandler("admin", self.admin_command))
        self.dispatcher.add_handler(CommandHandler("adduser", self.add_user_command))
        self.dispatcher.add_handler(CommandHandler("removeuser", self.remove_user_command))
        self.dispatcher.add_handler(CommandHandler("checkuser", self.check_user_command))
        self.dispatcher.add_handler(CommandHandler("listusers", self.list_users_command))
        self.dispatcher.add_handler(CommandHandler("broadcast", self.broadcast_command))
        self.dispatcher.add_handler(CommandHandler("channel_subscription", self.channel_subscription_command))
        
        # Callback queries
        self.dispatcher.add_handler(CallbackQueryHandler(self.admin_callback, pattern='^admin_'))
    
    @admin_required
    async def admin_command(self, update: Update, context: CallbackContext):
        """Show admin dashboard"""
        chat_id = update.effective_chat.id
        
        # Get active users count
        active_users = self.subscription_service.get_active_users()
        active_count = len(active_users)
        
        # Get total users count
        total_users = self.subscription_service.get_all_users()
        total_count = len(total_users)
        
        # Create admin dashboard message
        message = "👨‍💼 لوحة تحكم المشرف\n\n"
        message += f"📊 إحصائيات المستخدمين:\n"
        message += f"👥 إجمالي المستخدمين: {total_count}\n"
        message += f"✅ المستخدمين النشطين: {active_count}\n\n"
        message += f"📆 التاريخ: {datetime.now().strftime('%Y-%m-%d')}\n"
        message += f"⏰ الوقت: {datetime.now().strftime('%H:%M:%S')}\n\n"
        message += "اختر إحدى العمليات التالية:"
        
        # Create keyboard with admin options
        keyboard = [
            [InlineKeyboardButton("👥 عرض المستخدمين", callback_data="admin_list_users")],
            [InlineKeyboardButton("📢 إرسال رسالة جماعية", callback_data="admin_broadcast")],
            [InlineKeyboardButton("🔄 إعدادات الاشتراك الإجباري", callback_data="admin_channel_settings")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await context.bot.send_message(
            chat_id=chat_id,
            text=message,
            reply_markup=reply_markup
        )
    
    @admin_required
    async def add_user_command(self, update: Update, context: CallbackContext):
        """Add subscription for user"""
        chat_id = update.effective_chat.id
        
        # Check arguments
        if not context.args or len(context.args) < 2:
            await context.bot.send_message(
                chat_id=chat_id,
                text="⚠️ الاستخدام الصحيح: /adduser USER_ID DAYS\n\n"
                     "مثال: /adduser 123456789 30"
            )
            return
        
        # Parse arguments
        try:
            user_id = int(context.args[0])
            days = int(context.args[1])
        except ValueError:
            await context.bot.send_message(
                chat_id=chat_id,
                text="⚠️ يرجى إدخال USER_ID و DAYS كأرقام صحيحة."
            )
            return
        
        # Add subscription
        success, message = self.subscription_service.add_subscription(user_id, days)
        
        await context.bot.send_message(
            chat_id=chat_id,
            text=message
        )
    
    @admin_required
    async def remove_user_command(self, update: Update, context: CallbackContext):
        """Remove subscription for user"""
        chat_id = update.effective_chat.id
        
        # Check arguments
        if not context.args or len(context.args) < 1:
            await context.bot.send_message(
                chat_id=chat_id,
                text="⚠️ الاستخدام الصحيح: /removeuser USER_ID\n\n"
                     "مثال: /removeuser 123456789"
            )
            return
        
        # Parse arguments
        try:
            user_id = int(context.args[0])
        except ValueError:
            await context.bot.send_message(
                chat_id=chat_id,
                text="⚠️ يرجى إدخال USER_ID كرقم صحيح."
            )
            return
        
        # Remove subscription
        success, message = self.subscription_service.remove_subscription(user_id)
        
        await context.bot.send_message(
            chat_id=chat_id,
            text=message
        )
    
    @admin_required
    async def check_user_command(self, update: Update, context: CallbackContext):
        """Check subscription status for user"""
        chat_id = update.effective_chat.id
        
        # Check arguments
        if not context.args or len(context.args) < 1:
            await context.bot.send_message(
                chat_id=chat_id,
                text="⚠️ الاستخدام الصحيح: /checkuser USER_ID\n\n"
                     "مثال: /checkuser 123456789"
            )
            return
        
        # Parse arguments
        try:
            user_id = int(context.args[0])
        except ValueError:
            await context.bot.send_message(
                chat_id=chat_id,
                text="⚠️ يرجى إدخال USER_ID كرقم صحيح."
            )
            return
        
        # Get user
        user = self.subscription_service.get_user(user_id)
        
        if not user:
            await context.bot.send_message(
                chat_id=chat_id,
                text=f"❌ لم يتم العثور على مستخدم بالمعرف {user_id}."
            )
            return
        
        # Create user info message
        message = f"👤 معلومات المستخدم:\n\n"
        message += f"🆔 المعرف: {user.user_id}\n"
        message += f"👤 اسم المستخدم: @{user.username or 'غير متوفر'}\n"
        message += f"📝 الاسم: {user.first_name or 'غير متوفر'} {user.last_name or ''}\n\n"
        
        # Subscription info
        has_subscription = user.has_active_subscription()
        if has_subscription:
            end_date = user.subscription_end.strftime('%Y-%m-%d')
            days_left = (user.subscription_end - datetime.now()).days
            message += f"✅ الاشتراك: نشط\n"
            message += f"📅 تاريخ انتهاء الاشتراك: {end_date}\n"
            message += f"⏳ الأيام المتبقية: {days_left} يوم\n"
        else:
            message += f"❌ الاشتراك: غير نشط\n"
        
        # Create keyboard with admin options
        keyboard = [
            [
                InlineKeyboardButton("➕ تمديد الاشتراك", callback_data=f"admin_extend_{user_id}"),
                InlineKeyboardButton("❌ إلغاء الاشتراك", callback_data=f"admin_remove_{user_id}")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await context.bot.send_message(
            chat_id=chat_id,
            text=message,
            reply_markup=reply_markup
        )
    
    @admin_required
    async def list_users_command(self, update: Update, context: CallbackContext):
        """List active users"""
        chat_id = update.effective_chat.id
        
        # Get active users
        active_users = self.subscription_service.get_active_users()
        
        if not active_users:
            await context.bot.send_message(
                chat_id=chat_id,
                text="ℹ️ لا يوجد مستخدمين نشطين حالياً."
            )
            return
        
        # Create users list message
        message = f"👥 المستخدمين النشطين ({len(active_users)}):\n\n"
        
        for i, user in enumerate(active_users, 1):
            end_date = user.subscription_end.strftime('%Y-%m-%d')
            days_left = (user.subscription_end - datetime.now()).days
            
            message += f"{i}. 👤 @{user.username or 'غير متوفر'} ({user.user_id})\n"
            message += f"   📝 {user.first_name or 'غير متوفر'} {user.last_name or ''}\n"
            message += f"   📅 ينتهي في: {end_date} ({days_left} يوم)\n\n"
        
        await context.bot.send_message(
            chat_id=chat_id,
            text=message
        )
    
    @admin_required
    async def broadcast_command(self, update: Update, context: CallbackContext):
        """Send broadcast message to all users"""
        chat_id = update.effective_chat.id
        
        # Check if there's a message to broadcast
        if not context.args:
            await context.bot.send_message(
                chat_id=chat_id,
                text="⚠️ الاستخدام الصحيح: /broadcast YOUR_MESSAGE\n\n"
                     "مثال: /broadcast مرحباً بالجميع! هذا إعلان مهم."
            )
            return
        
        # Get message text
        message_text = ' '.join(context.args)
        
        # Get all users
        all_users = self.subscription_service.get_all_users()
        
        if not all_users:
            await context.bot.send_message(
                chat_id=chat_id,
                text="ℹ️ لا يوجد مستخدمين لإرسال الرسالة إليهم."
            )
            return
        
        # Send loading message
        loading_message = await context.bot.send_message(
            chat_id=chat_id,
            text=f"⏳ جاري إرسال الرسالة إلى {len(all_users)} مستخدم..."
        )
        
        # Send broadcast message
        success_count = 0
        fail_count = 0
        
        for user in all_users:
            try:
                await context.bot.send_message(
                    chat_id=user.user_id,
                    text=f"📢 رسالة من المشرف:\n\n{message_text}"
                )
                success_count += 1
            except Exception as e:
                fail_count += 1
                print(f"Error sending broadcast to {user.user_id}: {str(e)}")
        
        # Update loading message
        await context.bot.edit_message_text(
            chat_id=chat_id,
            message_id=loading_message.message_id,
            text=f"✅ تم إرسال الرسالة بنجاح!\n\n"
                 f"📊 الإحصائيات:\n"
                 f"✅ تم الإرسال: {success_count} مستخدم\n"
                 f"❌ فشل الإرسال: {fail_count} مستخدم"
        )
    
    @admin_required
    async def channel_subscription_command(self, update: Update, context: CallbackContext):
        """Manage required channel subscription"""
        chat_id = update.effective_chat.id
        
        # Get current channel settings
        channel_settings = self.subscription_service.get_channel_settings()
        
        # Create message
        message = "🔄 إعدادات الاشتراك الإجباري في القناة:\n\n"
        
        if channel_settings and channel_settings.get('enabled', False):
            channel_username = channel_settings.get('channel_username', 'غير متوفر')
            message += f"✅ الحالة: مفعل\n"
            message += f"📢 القناة: @{channel_username}\n\n"
            message += "يمكنك تغيير القناة أو تعطيل الاشتراك الإجباري."
        else:
            message += f"❌ الحالة: معطل\n\n"
            message += "يمكنك تفعيل الاشتراك الإجباري في القناة."
        
        # Create keyboard with options
        keyboard = []
        
        if channel_settings and channel_settings.get('enabled', False):
            keyboard.append([InlineKeyboardButton("❌ تعطيل الاشتراك الإجباري", callback_data="admin_channel_disable")])
            keyboard.append([InlineKeyboardButton("🔄 تغيير القناة", callback_data="admin_channel_change")])
        else:
            keyboard.append([InlineKeyboardButton("✅ تفعيل الاشتراك الإجباري", callback_data="admin_channel_enable")])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await context.bot.send_message(
            chat_id=chat_id,
            text=message,
            reply_markup=reply_markup
        )
    
    async def admin_callback(self, update: Update, context: CallbackContext):
        """Handle admin-related callbacks"""
        query = update.callback_query
        await query.answer()
        
        user_id = update.effective_user.id
        data = query.data
        
        # Check if user is admin
        user = self.subscription_service.get_user(user_id)
        if not user or not user.is_admin:
            await query.edit_message_text(
                text="⚠️ ليس لديك صلاحيات كافية للقيام بهذه العملية."
            )
            return
        
        if data == "admin_list_users":
            # Show active users
            active_users = self.subscription_service.get_active_users()
            
            if not active_users:
                await query.edit_message_text(
                    text="ℹ️ لا يوجد مستخدمين نشطين حالياً."
                )
                return
            
            # Create users list message
            message = f"👥 المستخدمين النشطين ({len(active_users)}):\n\n"
            
            for i, user in enumerate(active_users[:10], 1):  # Show only first 10 users
                end_date = user.subscription_end.strftime('%Y-%m-%d')
                days_left = (user.subscription_end - datetime.now()).days
                
                message += f"{i}. 👤 @{user.username or 'غير متوفر'} ({user.user_id})\n"
                message += f"   📅 ينتهي في: {end_date} ({days_left} يوم)\n"
            
            if len(active_users) > 10:
                message += f"\n... و {len(active_users) - 10} مستخدم آخر."
            
            # Create back button
            keyboard = [
                [InlineKeyboardButton("🔙 رجوع", callback_data="admin_back")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                text=message,
                reply_markup=reply_markup
            )
        
        elif data == "admin_broadcast":
            # Show broadcast instructions
            message = "📢 إرسال رسالة جماعية:\n\n"
            message += "لإرسال رسالة جماعية لجميع المستخدمين، استخدم الأمر:\n"
            message += "/broadcast YOUR_MESSAGE\n\n"
            message += "مثال:\n"
            message += "/broadcast مرحباً بالجميع! هذا إعلان مهم."
            
            # Create back button
            keyboard = [
                [InlineKeyboardButton("🔙 رجوع", callback_data="admin_back")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                text=message,
                reply_markup=reply_markup
            )
        
        elif data == "admin_channel_settings":
            # Show channel subscription settings
            await self.channel_subscription_command(update, context)
        
        elif data == "admin_channel_enable":
            # Show enable channel subscription form
            message = "✅ تفعيل الاشتراك الإجباري في القناة:\n\n"
            message += "يرجى إرسال اسم مستخدم القناة (بدون @):\n\n"
            message += "مثال: mychannel"
            
            # Create back button
            keyboard = [
                [InlineKeyboardButton("🔙 رجوع", callback_data="admin_back")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                text=message,
                reply_markup=reply_markup
            )
            
            # Set next state
            context.user_data['admin_state'] = 'waiting_channel_username'
        
        elif data == "admin_channel_disable":
            # Disable channel subscription
            self.subscription_service.disable_channel_subscription()
            
            await query.edit_message_text(
                text="✅ تم تعطيل الاشتراك الإجباري في القناة بنجاح.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 رجوع", callback_data="admin_back")]])
            )
        
        elif data == "admin_channel_change":
            # Show change channel form
            message = "🔄 تغيير القناة المطلوبة للاشتراك:\n\n"
            message += "يرجى إرسال اسم مستخدم القناة الجديدة (بدون @):\n\n"
            message += "مثال: mychannel"
            
            # Create back button
            keyboard = [
                [InlineKeyboardButton("🔙 رجوع", callback_data="admin_back")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                text=message,
                reply_markup=reply_markup
            )
            
            # Set next state
            context.user_data['admin_state'] = 'waiting_channel_username'
        
        elif data == "admin_back":
            # Go back to admin dashboard
            await self.admin_command(update, context)
        
        elif data.startswith("admin_extend_"):
            # Extend user subscription
            target_user_id = int(data.split("_")[2])
            
            # Add 30 days to subscription
            success, message = self.subscription_service.add_subscription(target_user_id, 30)
            
            await query.edit_message_text(
                text=message
            )
        
        elif data.startswith("admin_remove_"):
            # Remove user subscription
            target_user_id = int(data.split("_")[2])
            
            # Remove subscription
            success, message = self.subscription_service.remove_subscription(target_user_id)
            
            await query.edit_message_text(
                text=message
            )
