from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import CallbackContext, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ConversationHandler
from services.auth_service import AuthService
from utils.decorators import subscription_required
import re
import json
from telethon.sessions import StringSession
from telethon import TelegramClient
import asyncio
import os
import logging

# إعداد التسجيل
logger = logging.getLogger(__name__)

# Conversation states
API_ID = 1
API_HASH = 2
PHONE_NUMBER = 3
VERIFICATION_CODE = 4
PASSWORD = 5

class SessionHandlers:
    def __init__(self, dispatcher):
        self.dispatcher = dispatcher
        self.auth_service = AuthService()
        
        # Register handlers
        self.register_handlers()
    
    def register_handlers(self):
        # Session generation conversation handler
        session_conv_handler = ConversationHandler(
            entry_points=[CommandHandler("generate_session", self.generate_session_command)],
            states={
                API_ID: [MessageHandler(filters.TEXT & ~filters.COMMAND, self.api_id_handler)],
                API_HASH: [MessageHandler(filters.TEXT & ~filters.COMMAND, self.api_hash_handler)],
                PHONE_NUMBER: [MessageHandler(filters.TEXT & ~filters.COMMAND, self.phone_number_handler)],
                VERIFICATION_CODE: [MessageHandler(filters.TEXT & ~filters.COMMAND, self.verification_code_handler)],
                PASSWORD: [MessageHandler(filters.TEXT & ~filters.COMMAND, self.password_handler)],
            },
            fallbacks=[CommandHandler("cancel", self.cancel_handler)],
        )
        
        self.dispatcher.add_handler(session_conv_handler)
        
        # Add API info command
        self.dispatcher.add_handler(CommandHandler("api_info", self.api_info_command))
        self.dispatcher.add_handler(CommandHandler("ipa_info", self.api_info_command))  # إضافة أمر بديل للتوافق
        
        # Add callback handler for auth_generate_session
        self.dispatcher.add_handler(CallbackQueryHandler(self.auth_generate_session_callback, pattern='^auth_generate_session$'))
    
    @subscription_required
    async def generate_session_command(self, update: Update, context: CallbackContext):
        """Start the session generation process"""
        chat_id = update.effective_chat.id
        user_id = update.effective_user.id
        
        # Send welcome message with instructions
        await context.bot.send_message(
            chat_id=chat_id,
            text="🔐 مرحباً بك في عملية إنشاء Session String!\n\n"
                 "هذه العملية ستساعدك على إنشاء Session String لاستخدامه في البوت.\n\n"
                 "ستحتاج إلى:\n"
                 "1️⃣ API ID (من my.telegram.org)\n"
                 "2️⃣ API Hash (من my.telegram.org)\n"
                 "3️⃣ رقم هاتفك المسجل في تيليجرام\n\n"
                 "إذا لم تكن تعرف كيفية الحصول على API ID و API Hash، استخدم الأمر /api_info للحصول على شرح مفصل.\n\n"
                 "يمكنك إلغاء العملية في أي وقت باستخدام الأمر /cancel.\n\n"
                 "الآن، يرجى إدخال API ID الخاص بك:"
        )
        
        return API_ID
    
    async def api_id_handler(self, update: Update, context: CallbackContext):
        """Handle API ID input"""
        chat_id = update.effective_chat.id
        api_id = update.message.text.strip()
        
        # Validate API ID
        try:
            api_id = int(api_id)
            context.user_data['api_id'] = api_id
        except ValueError:
            await context.bot.send_message(
                chat_id=chat_id,
                text="⚠️ يرجى إدخال API ID صحيح (أرقام فقط):"
            )
            return API_ID
        
        await context.bot.send_message(
            chat_id=chat_id,
            text="👍 تم استلام API ID بنجاح!\n\n"
                 "الآن، يرجى إدخال API Hash الخاص بك:"
        )
        
        return API_HASH
    
    async def api_hash_handler(self, update: Update, context: CallbackContext):
        """Handle API Hash input"""
        chat_id = update.effective_chat.id
        api_hash = update.message.text.strip()
        
        # Validate API Hash (simple validation)
        if len(api_hash) < 10:
            await context.bot.send_message(
                chat_id=chat_id,
                text="⚠️ يرجى إدخال API Hash صحيح (يجب أن يكون أطول من 10 أحرف):"
            )
            return API_HASH
        
        context.user_data['api_hash'] = api_hash
        
        await context.bot.send_message(
            chat_id=chat_id,
            text="👍 تم استلام API Hash بنجاح!\n\n"
                 "الآن، يرجى إدخال رقم هاتفك المسجل في تيليجرام (مع رمز الدولة، مثال: +966501234567):"
        )
        
        return PHONE_NUMBER
    
    async def phone_number_handler(self, update: Update, context: CallbackContext):
        """Handle phone number input"""
        chat_id = update.effective_chat.id
        user_id = update.effective_user.id
        phone_number = update.message.text.strip()
        
        # Validate phone number format (simple validation)
        if not phone_number.startswith('+'):
            await context.bot.send_message(
                chat_id=chat_id,
                text="⚠️ يرجى إدخال رقم هاتف صحيح مع رمز الدولة (يبدأ بـ +):"
            )
            return PHONE_NUMBER
        
        context.user_data['phone_number'] = phone_number
        
        # Send loading message
        loading_message = await context.bot.send_message(
            chat_id=chat_id,
            text="⏳ جاري إرسال رمز التحقق إلى رقم هاتفك..."
        )
        
        try:
            # Create Telethon client
            api_id = context.user_data['api_id']
            api_hash = context.user_data['api_hash']
            
            # Create a temporary file for session
            temp_session_file = f"/tmp/temp_session_{user_id}"
            
            # Create client
            client = TelegramClient(temp_session_file, api_id, api_hash)
            await client.connect()
            
            # Send code request
            await client.send_code_request(phone_number)
            
            # Store client in user_data
            context.user_data['client'] = client
            
            # Update loading message
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=loading_message.message_id,
                text="✅ تم إرسال رمز التحقق إلى رقم هاتفك!\n\n"
                     "يرجى إدخال رمز التحقق الذي استلمته:"
            )
            
            return VERIFICATION_CODE
            
        except Exception as e:
            # Handle error
            error_message = str(e)
            logger.error(f"خطأ في إرسال رمز التحقق: {error_message}")
            
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=loading_message.message_id,
                text=f"❌ حدث خطأ أثناء إرسال رمز التحقق:\n{error_message}\n\n"
                     f"يرجى التحقق من API ID و API Hash ورقم الهاتف والمحاولة مرة أخرى."
            )
            
            # Clean up
            context.user_data.clear()
            
            return ConversationHandler.END
    
    async def verification_code_handler(self, update: Update, context: CallbackContext):
        """Handle verification code input"""
        chat_id = update.effective_chat.id
        user_id = update.effective_user.id
        verification_code = update.message.text.strip()
        
        # Send loading message
        loading_message = await context.bot.send_message(
            chat_id=chat_id,
            text="⏳ جاري التحقق من الرمز..."
        )
        
        try:
            # Get client from user_data
            client = context.user_data['client']
            phone_number = context.user_data['phone_number']
            
            # Try to sign in
            try:
                await client.sign_in(phone_number, verification_code)
                
                # If successful, generate session string
                session_string = StringSession.save(client.session)
                
                # Save session string to database
                self.auth_service.save_user_session(user_id, session_string)
                
                # Update loading message with session string for extraction
                await context.bot.edit_message_text(
                    chat_id=chat_id,
                    message_id=loading_message.message_id,
                    text=f"✅ تم تسجيل الدخول بنجاح وتم حفظ Session String!\n\n"
                         f"Session String الخاص بك:\n`{session_string}`\n\n"
                         f"يمكنك الآن استخدام البوت بكامل ميزاته.\n\n"
                         f"ملاحظة: احتفظ بهذه القيمة في مكان آمن ولا تشاركها مع أي شخص."
                )
                
                # Clean up
                await client.disconnect()
                if os.path.exists(f"/tmp/temp_session_{user_id}"):
                    os.remove(f"/tmp/temp_session_{user_id}")
                context.user_data.clear()
                
                return ConversationHandler.END
                
            except Exception as e:
                error_message = str(e)
                logger.error(f"خطأ في تسجيل الدخول: {error_message}")
                
                # Check if two-factor authentication is enabled
                if "2FA" in error_message or "password" in error_message.lower():
                    await context.bot.edit_message_text(
                        chat_id=chat_id,
                        message_id=loading_message.message_id,
                        text="🔐 يبدو أن حسابك محمي بكلمة مرور (المصادقة الثنائية).\n\n"
                             "يرجى إدخال كلمة المرور الخاصة بك:"
                    )
                    
                    return PASSWORD
                else:
                    # Other error
                    await context.bot.edit_message_text(
                        chat_id=chat_id,
                        message_id=loading_message.message_id,
                        text=f"❌ حدث خطأ أثناء تسجيل الدخول:\n{error_message}\n\n"
                             f"يرجى التحقق من رمز التحقق والمحاولة مرة أخرى."
                    )
                    
                    return VERIFICATION_CODE
            
        except Exception as e:
            # Handle error
            error_message = str(e)
            logger.error(f"خطأ غير متوقع: {error_message}")
            
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=loading_message.message_id,
                text=f"❌ حدث خطأ غير متوقع:\n{error_message}\n\n"
                     f"يرجى المحاولة مرة أخرى لاحقاً."
            )
            
            # Clean up
            if 'client' in context.user_data:
                client = context.user_data['client']
                await client.disconnect()
            if os.path.exists(f"/tmp/temp_session_{user_id}"):
                os.remove(f"/tmp/temp_session_{user_id}")
            context.user_data.clear()
            
            return ConversationHandler.END
    
    async def password_handler(self, update: Update, context: CallbackContext):
        """Handle 2FA password input"""
        chat_id = update.effective_chat.id
        user_id = update.effective_user.id
        password = update.message.text.strip()
        
        # Delete the message containing the password for security
        await update.message.delete()
        
        # Send loading message
        loading_message = await context.bot.send_message(
            chat_id=chat_id,
            text="⏳ جاري التحقق من كلمة المرور..."
        )
        
        try:
            # Get client from user_data
            client = context.user_data['client']
            
            # Try to sign in with password
            await client.sign_in(password=password)
            
            # If successful, generate session string
            session_string = StringSession.save(client.session)
            
            # Save session string to database
            self.auth_service.save_user_session(user_id, session_string)
            
            # Update loading message with session string for extraction
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=loading_message.message_id,
                text=f"✅ تم تسجيل الدخول بنجاح وتم حفظ Session String!\n\n"
                     f"Session String الخاص بك:\n`{session_string}`\n\n"
                     f"يمكنك الآن استخدام البوت بكامل ميزاته.\n\n"
                     f"ملاحظة: احتفظ بهذه القيمة في مكان آمن ولا تشاركها مع أي شخص."
            )
            
            # Clean up
            await client.disconnect()
            if os.path.exists(f"/tmp/temp_session_{user_id}"):
                os.remove(f"/tmp/temp_session_{user_id}")
            context.user_data.clear()
            
            return ConversationHandler.END
            
        except Exception as e:
            # Handle error
            error_message = str(e)
            logger.error(f"خطأ في تسجيل الدخول بكلمة المرور: {error_message}")
            
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=loading_message.message_id,
                text=f"❌ حدث خطأ أثناء تسجيل الدخول:\n{error_message}\n\n"
                     f"يرجى التحقق من كلمة المرور والمحاولة مرة أخرى."
            )
            
            return PASSWORD
    
    async def cancel_handler(self, update: Update, context: CallbackContext):
        """Cancel the conversation"""
        chat_id = update.effective_chat.id
        user_id = update.effective_user.id
        
        # Clean up
        if 'client' in context.user_data:
            client = context.user_data['client']
            await client.disconnect()
        if os.path.exists(f"/tmp/temp_session_{user_id}"):
            os.remove(f"/tmp/temp_session_{user_id}")
        context.user_data.clear()
        
        await context.bot.send_message(
            chat_id=chat_id,
            text="❌ تم إلغاء عملية إنشاء Session String."
        )
        
        return ConversationHandler.END
    
    async def api_info_command(self, update: Update, context: CallbackContext):
        """Show information about how to get API ID and API Hash"""
        chat_id = update.effective_chat.id
        
        # Create message with instructions
        message = "🔑 كيفية الحصول على API ID و API Hash:\n\n"
        message += "1️⃣ قم بزيارة الموقع الرسمي: https://my.telegram.org\n\n"
        message += "2️⃣ قم بتسجيل الدخول باستخدام رقم هاتفك المسجل في تيليجرام\n\n"
        message += "3️⃣ انقر على 'API development tools'\n\n"
        message += "4️⃣ أدخل المعلومات المطلوبة (يمكنك إدخال أي اسم تطبيق ووصف)\n\n"
        message += "5️⃣ بعد الإرسال، ستظهر لك صفحة تحتوي على API ID و API Hash\n\n"
        message += "6️⃣ استخدم هذه المعلومات في الأمر /generate_session\n\n"
        message += "⚠️ ملاحظة مهمة: لا تشارك API ID و API Hash الخاصة بك مع أي شخص آخر!"
        
        # Create keyboard with generate session button
        keyboard = [
            [InlineKeyboardButton("🔐 إنشاء Session String", callback_data="auth_generate_session")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await context.bot.send_message(
            chat_id=chat_id,
            text=message,
            reply_markup=reply_markup
        )
    
    async def auth_generate_session_callback(self, update: Update, context: CallbackContext):
        """Handle auth_generate_session callback"""
        query = update.callback_query
        await query.answer()
        
        # Redirect to generate_session command
        await query.edit_message_text(
            text="🔐 سيتم توجيهك إلى عملية إنشاء Session String.\n\n"
                 "يرجى استخدام الأمر /generate_session للبدء."
        )
        
        # Send the generate_session command message
        chat_id = update.effective_chat.id
        await context.bot.send_message(
            chat_id=chat_id,
            text="🔐 مرحباً بك في عملية إنشاء Session String!\n\n"
                 "هذه العملية ستساعدك على إنشاء Session String لاستخدامه في البوت.\n\n"
                 "ستحتاج إلى:\n"
                 "1️⃣ API ID (من my.telegram.org)\n"
                 "2️⃣ API Hash (من my.telegram.org)\n"
                 "3️⃣ رقم هاتفك المسجل في تيليجرام\n\n"
                 "إذا لم تكن تعرف كيفية الحصول على API ID و API Hash، استخدم الأمر /api_info للحصول على شرح مفصل.\n\n"
                 "يمكنك إلغاء العملية في أي وقت باستخدام الأمر /cancel.\n\n"
                 "الآن، يرجى إدخال API ID الخاص بك:"
        )
        
        # Set conversation state
        context.user_data['conversation_state'] = API_ID
        
        # Return API_ID state
        return API_ID
