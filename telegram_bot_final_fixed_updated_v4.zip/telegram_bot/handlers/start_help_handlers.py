from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import CallbackContext, CommandHandler, CallbackQueryHandler
from services.subscription_service import SubscriptionService
from services.auth_service import AuthService
from services.group_service import GroupService
from services.posting_service import PostingService
from services.response_service import ResponseService
from services.referral_service import ReferralService

class StartHelpHandlers:
    def __init__(self, dispatcher):
        self.dispatcher = dispatcher
        self.subscription_service = SubscriptionService()
        self.auth_service = AuthService()
        self.group_service = GroupService()
        self.posting_service = PostingService()
        self.response_service = ResponseService()
        self.referral_service = ReferralService()
        
        # Register handlers
        self.register_handlers()
    
    def register_handlers(self):
        # Register start and help commands
        self.dispatcher.add_handler(CommandHandler("start", self.start_command))
        self.dispatcher.add_handler(CommandHandler("help", self.help_command))
        
        # Register callback queries - Fix: Use more specific pattern to avoid conflicts
        self.dispatcher.add_handler(CallbackQueryHandler(self.start_help_callback, pattern='^(start_|help_)'))
    
    async def start_command(self, update: Update, context: CallbackContext):
        """Handle the /start command with interactive buttons"""
        user = update.effective_user
        user_id = user.id
        
        # Get or create user in database
        db_user = self.subscription_service.get_user(user_id)
        if not db_user:
            db_user = self.subscription_service.create_user(
                user_id,
                user.username,
                user.first_name,
                user.last_name
            )
        
        # Check if admin
        is_admin = db_user and db_user.is_admin
        
        # Welcome message
        welcome_text = f"👋 مرحباً {user.first_name}!\n\n"
        
        if is_admin:
            welcome_text += "🔰 أنت مسجل كمشرف في النظام.\n\n"
        
        welcome_text += "🤖 أنا بوت احترافي للنشر التلقائي في مجموعات تيليجرام.\n\n"
        
        # Check subscription status
        has_subscription = db_user.has_active_subscription()
        
        # Create keyboard with options
        keyboard = []
        
        # Add referral button for all users (new feature)
        keyboard.append([
            InlineKeyboardButton("🔗 الإحالة", callback_data="start_referral")
        ])
        
        if has_subscription:
            end_date = db_user.subscription_end.strftime('%Y-%m-%d')
            welcome_text += f"✅ لديك اشتراك نشط حتى: {end_date}\n\n"
            
            # Check if user is logged in
            session_string = self.auth_service.get_user_session(user_id)
            if session_string:
                welcome_text += "✅ أنت مسجل الدخول بالفعل ويمكنك استخدام جميع ميزات البوت.\n\n"
                
                # Add main feature buttons
                keyboard.append([
                    InlineKeyboardButton("👥 المجموعات", callback_data="start_groups"),
                    InlineKeyboardButton("📝 النشر", callback_data="start_post")
                ])
                
                keyboard.append([
                    InlineKeyboardButton("🤖 الردود التلقائية", callback_data="start_responses")
                ])
                
                # Add account management buttons
                keyboard.append([
                    InlineKeyboardButton("🔄 تحديث المجموعات", callback_data="start_refresh_groups"),
                    InlineKeyboardButton("📊 حالة النشر", callback_data="start_status")
                ])
                
                keyboard.append([
                    InlineKeyboardButton("📋 المساعدة", callback_data="start_help")
                ])
                
                # Add admin button if user is admin
                if is_admin:
                    keyboard.append([
                        InlineKeyboardButton("👨‍💼 لوحة المشرف", callback_data="start_admin")
                    ])
            else:
                welcome_text += "⚠️ أنت لم تقم بتسجيل الدخول بعد.\n\n"
                
                # Add login buttons
                keyboard.append([
                    InlineKeyboardButton("🔑 تسجيل الدخول", callback_data="start_login"),
                    InlineKeyboardButton("🔐 إنشاء Session", callback_data="start_generate_session")
                ])
                
                keyboard.append([
                    InlineKeyboardButton("📋 المساعدة", callback_data="start_help")
                ])
                
                # Add admin button if user is admin
                if is_admin:
                    keyboard.append([
                        InlineKeyboardButton("👨‍💼 لوحة المشرف", callback_data="start_admin")
                    ])
        else:
            welcome_text += "⚠️ ليس لديك اشتراك نشط.\n\n"
            
            # Create keyboard with subscription option
            keyboard.append([
                InlineKeyboardButton("🔔 طلب اشتراك", callback_data="start_subscription")
            ])
            
            keyboard.append([
                InlineKeyboardButton("📋 المساعدة", callback_data="start_help")
            ])
            
            # Add admin button if user is admin
            if is_admin:
                keyboard.append([
                    InlineKeyboardButton("👨‍💼 لوحة المشرف", callback_data="start_admin")
                ])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            text=welcome_text,
            reply_markup=reply_markup
        )
    
    async def help_command(self, update: Update, context: CallbackContext):
        """Handle the /help command with interactive buttons"""
        user = update.effective_user
        user_id = user.id
        
        # Get user from database
        db_user = self.subscription_service.get_user(user_id)
        is_admin = db_user and db_user.is_admin
        has_subscription = db_user and db_user.has_active_subscription()
        
        help_text = "📋 قائمة الأوامر المتاحة:\n\n"
        
        # Create keyboard with help categories
        keyboard = [
            [InlineKeyboardButton("🔑 أوامر الحساب", callback_data="help_account")],
            [InlineKeyboardButton("👥 أوامر المجموعات", callback_data="help_groups")],
            [InlineKeyboardButton("📝 أوامر النشر", callback_data="help_posting")],
            [InlineKeyboardButton("🤖 أوامر الردود", callback_data="help_responses")],
            [InlineKeyboardButton("🔗 أوامر الإحالات", callback_data="help_referrals")]
        ]
        
        # Add admin button if user is admin
        if is_admin:
            keyboard.append([
                InlineKeyboardButton("👨‍💼 أوامر المشرف", callback_data="help_admin")
            ])
        
        # Add back to start button
        keyboard.append([
            InlineKeyboardButton("🔙 العودة للبداية", callback_data="help_back_to_start")
        ])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            text=help_text,
            reply_markup=reply_markup
        )
    
    async def start_help_callback(self, update: Update, context: CallbackContext):
        """Handle start and help related callbacks"""
        query = update.callback_query
        await query.answer()
        
        user_id = update.effective_user.id
        data = query.data
        
        # Get user from database
        db_user = self.subscription_service.get_user(user_id)
        is_admin = db_user and db_user.is_admin
        has_subscription = db_user and db_user.has_active_subscription()
        
        # Handle start callbacks
        if data == "start_subscription":
            # Redirect to subscription command
            await query.edit_message_text(
                text="🔔 يرجى استخدام الأمر /subscription لطلب اشتراك."
            )
        
        elif data == "start_login":
            # Redirect to login command
            await query.edit_message_text(
                text="🔑 يرجى استخدام الأمر /login لتسجيل الدخول."
            )
        
        elif data == "start_generate_session":
            # Redirect to generate session command
            await query.edit_message_text(
                text="🔐 يرجى استخدام الأمر /generate_session لإنشاء Session String."
            )
        
        elif data == "start_groups":
            # Redirect to groups command
            await query.edit_message_text(
                text="👥 يرجى استخدام الأمر /groups لإدارة المجموعات."
            )
        
        elif data == "start_post":
            # Redirect to post command
            await query.edit_message_text(
                text="📝 يرجى استخدام الأمر /post لبدء النشر في المجموعات."
            )
        
        elif data == "start_responses":
            # Redirect to auto_response command
            await query.edit_message_text(
                text="🤖 يرجى استخدام الأمر /auto_response للتحكم في الردود التلقائية."
            )
        
        elif data == "start_referral":
            # Redirect to referral command - now available to all users
            await query.edit_message_text(
                text="🔗 يرجى استخدام الأمر /referral للحصول على رابط الإحالة الخاص بك."
            )
        
        elif data == "start_refresh_groups":
            # تصحيح: تغيير الأمر من refresh_groups إلى refresh
            await query.edit_message_text(
                text="🔄 يرجى استخدام الأمر /refresh لتحديث قائمة المجموعات."
            )
        
        elif data == "start_status":
            # Redirect to status command
            await query.edit_message_text(
                text="📊 يرجى استخدام الأمر /status للتحقق من حالة النشر الحالية."
            )
        
        elif data == "start_admin":
            # Redirect to admin command
            await query.edit_message_text(
                text="👨‍💼 يرجى استخدام الأمر /admin للوصول إلى لوحة المشرف."
            )
        
        elif data == "start_help":
            # Redirect to help command
            await self.help_command(update, context)
        
        # Handle help callbacks
        elif data == "help_account":
            # Show account commands
            message = "🔑 أوامر الحساب:\n\n"
            message += "🔹 /subscription - التحقق من حالة الاشتراك\n"
            message += "🔹 /login - تسجيل الدخول إلى حساب التيليجرام\n"
            message += "🔹 /logout - تسجيل الخروج من حساب التيليجرام\n"
            message += "🔹 /generate_session - توليد Session String جديد\n"
            message += "🔹 /api_info - معلومات حول كيفية الحصول على API ID و API Hash\n"
            
            # Create back button
            keyboard = [
                [InlineKeyboardButton("🔙 رجوع", callback_data="help_back")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                text=message,
                reply_markup=reply_markup
            )
        
        elif data == "help_groups":
            # Show groups commands
            message = "👥 أوامر المجموعات:\n\n"
            message += "🔹 /groups - إدارة المجموعات\n"
            # تصحيح: إضافة جميع أوامر تحديث المجموعات
            message += "🔹 /refresh - تحديث قائمة المجموعات\n"
            message += "🔹 /refresh_group - تحديث قائمة المجموعات\n"
            message += "🔹 /refresh_groups - تحديث قائمة المجموعات\n"
            
            # Create back button
            keyboard = [
                [InlineKeyboardButton("🔙 رجوع", callback_data="help_back")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                text=message,
                reply_markup=reply_markup
            )
        
        elif data == "help_posting":
            # Show posting commands
            message = "📝 أوامر النشر:\n\n"
            message += "🔹 /post - بدء عملية النشر في المجموعات\n"
            # تصحيح: تغيير الأمر من stop_posting إلى stop
            message += "🔹 /stop - إيقاف عملية النشر الحالية\n"
            message += "🔹 /status - التحقق من حالة النشر الحالية\n"
            
            # Create back button
            keyboard = [
                [InlineKeyboardButton("🔙 رجوع", callback_data="help_back")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                text=message,
                reply_markup=reply_markup
            )
        
        elif data == "help_responses":
            # Show responses commands
            message = "🤖 أوامر الردود التلقائية:\n\n"
            message += "🔹 /auto_response - التحكم في الردود التلقائية\n"
            message += "🔹 /start_responses - تفعيل الردود التلقائية\n"
            message += "🔹 /stop_responses - إيقاف الردود التلقائية\n"
            message += "🔹 /customize_responses - تخصيص الردود التلقائية\n"
            
            # Create back button
            keyboard = [
                [InlineKeyboardButton("🔙 رجوع", callback_data="help_back")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                text=message,
                reply_markup=reply_markup
            )
        
        elif data == "help_referrals":
            # Show referrals commands
            message = "🔗 أوامر الإحالات:\n\n"
            message += "🔹 /referral - الحصول على رابط الإحالة الخاص بك\n"
            message += "🔹 /my_referrals - عرض إحالاتك\n"
            
            # Create back button
            keyboard = [
                [InlineKeyboardButton("🔙 رجوع", callback_data="help_back")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                text=message,
                reply_markup=reply_markup
            )
        
        elif data == "help_admin":
            # Show admin commands
            message = "👨‍💼 أوامر المشرف:\n\n"
            message += "🔹 /admin - لوحة تحكم المشرف\n"
            message += "🔹 /adduser USER_ID DAYS - إضافة اشتراك لمستخدم\n"
            message += "🔹 /removeuser USER_ID - إلغاء اشتراك مستخدم\n"
            message += "🔹 /checkuser USER_ID - التحقق من حالة اشتراك مستخدم\n"
            message += "🔹 /listusers - عرض قائمة المستخدمين مع اشتراكات نشطة\n"
            message += "🔹 /broadcast MESSAGE - إرسال رسالة جماعية لجميع المستخدمين\n"
            message += "🔹 /channel_subscription - إدارة الاشتراك الإجباري في القناة\n"
            
            # Create back button
            keyboard = [
                [InlineKeyboardButton("🔙 رجوع", callback_data="help_back")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                text=message,
                reply_markup=reply_markup
            )
        
        # Fix: Properly handle back button callbacks
        elif data == "help_back":
            # Go back to help main menu
            try:
                # Use the help_command method but with the callback query
                help_text = "📋 قائمة الأوامر المتاحة:\n\n"
                
                # Create keyboard with help categories
                keyboard = [
                    [InlineKeyboardButton("🔑 أوامر الحساب", callback_data="help_account")],
                    [InlineKeyboardButton("👥 أوامر المجموعات", callback_data="help_groups")],
                    [InlineKeyboardButton("📝 أوامر النشر", callback_data="help_posting")],
                    [InlineKeyboardButton("🤖 أوامر الردود", callback_data="help_responses")],
                    [InlineKeyboardButton("🔗 أوامر الإحالات", callback_data="help_referrals")]
                ]
                
                # Add admin button if user is admin
                if is_admin:
                    keyboard.append([
                        InlineKeyboardButton("👨‍💼 أوامر المشرف", callback_data="help_admin")
                    ])
                
                # Add back to start button
                keyboard.append([
                    InlineKeyboardButton("🔙 العودة للبداية", callback_data="help_back_to_start")
                ])
                
                reply_markup = InlineKeyboardMarkup(keyboard)
                
                await query.edit_message_text(
                    text=help_text,
                    reply_markup=reply_markup
                )
            except Exception as e:
                # If there's an error, just send a new help message
                await self.help_command(update, context)
        
        elif data == "help_back_to_start":
            # Go back to start command
            await self.start_command(update, context)
