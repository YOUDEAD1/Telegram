from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import CallbackContext, CommandHandler, CallbackQueryHandler, MessageHandler, filters
from services.group_service import GroupService
from services.subscription_service import SubscriptionService
from utils.decorators import subscription_required
import re
import json
import logging

# Configure logging
logger = logging.getLogger(__name__)

class GroupHandlers:
    def __init__(self, dispatcher):
        self.dispatcher = dispatcher
        self.group_service = GroupService()
        self.subscription_service = SubscriptionService()
        self.logger = logging.getLogger(__name__)
        
        # Register handlers
        self.register_handlers()
    
    def register_handlers(self):
        # Group management commands
        self.dispatcher.add_handler(CommandHandler("groups", self.groups_command))
        self.dispatcher.add_handler(CommandHandler("refresh_groups", self.refresh_groups_command))
        # تصحيح: إضافة أمر refresh كاختصار لـ refresh_groups
        self.dispatcher.add_handler(CommandHandler("refresh", self.refresh_groups_command))
        self.dispatcher.add_handler(CommandHandler("refresh_group", self.refresh_groups_command))
        # إضافة أمر freshgroup كاختصار لـ refresh_groups
        self.dispatcher.add_handler(CommandHandler("freshgroup", self.refresh_groups_command))
        
        # Callback queries
        self.dispatcher.add_handler(CallbackQueryHandler(self.group_callback, pattern='^group_'))
    
    @subscription_required
    async def groups_command(self, update: Update, context: CallbackContext):
        """Show user groups and allow management"""
        chat_id = update.effective_chat.id
        user_id = update.effective_user.id
        
        # Get user groups from database
        groups = self.group_service.get_user_groups(user_id)
        
        if not groups:
            # No groups found, offer to fetch them
            keyboard = [
                [InlineKeyboardButton("🔴 🟢 جلب المجموعات", callback_data="group_refresh")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await context.bot.send_message(
                chat_id=chat_id,
                text="⚠️ لم يتم العثور على مجموعات. يرجى جلب المجموعات أولاً.",
                reply_markup=reply_markup
            )
            return
        
        # Create keyboard with groups
        await self.send_groups_keyboard(update, context, groups)
    
    @subscription_required
    async def refresh_groups_command(self, update: Update, context: CallbackContext):
        """Refresh user groups from Telegram"""
        chat_id = update.effective_chat.id
        user_id = update.effective_user.id
        
        # Send loading message
        message = await context.bot.send_message(
            chat_id=chat_id,
            text="⏳ جاري جلب المجموعات من تيليجرام..."
        )
        
        # Fetch groups
        success, result_message, groups = await self.group_service.fetch_user_groups(user_id)
        
        if success:
            # Update message with success
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=message.message_id,
                text=f"✅ {result_message}"
            )
            
            # Show groups keyboard - تأكد من إظهار المجموعات مباشرة بعد التحديث
            if groups:
                # تحويل المجموعات من تنسيق API إلى تنسيق قاعدة البيانات
                db_groups = []
                for group in groups:
                    db_groups.append({
                        'group_id': group['id'],
                        'title': group['title'],
                        'blacklisted': False  # افتراضياً، المجموعات غير محظورة
                    })
                
                # إظهار المجموعات مباشرة
                await self.send_groups_keyboard(update, context, db_groups)
            else:
                await context.bot.send_message(
                    chat_id=chat_id,
                    text="⚠️ لم يتم العثور على مجموعات."
                )
        else:
            # Update message with error
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=message.message_id,
                text=f"❌ {result_message}"
            )
    
    async def group_callback(self, update: Update, context: CallbackContext):
        """Handle group-related callbacks"""
        query = update.callback_query
        await query.answer()
        
        user_id = update.effective_user.id
        data = query.data
        
        if data == "group_refresh":
            # Refresh groups
            await query.edit_message_text(
                text="⏳ جاري جلب المجموعات من تيليجرام..."
            )
            
            # Fetch groups
            success, result_message, groups = await self.group_service.fetch_user_groups(user_id)
            
            if success:
                # Update message with success
                await query.edit_message_text(
                    text=f"✅ {result_message}"
                )
                
                # Show groups keyboard - تأكد من إظهار المجموعات مباشرة بعد التحديث
                if groups:
                    # تحويل المجموعات من تنسيق API إلى تنسيق قاعدة البيانات
                    db_groups = []
                    for group in groups:
                        db_groups.append({
                            'group_id': group['id'],
                            'title': group['title'],
                            'blacklisted': False  # افتراضياً، المجموعات غير محظورة
                        })
                    
                    # إظهار المجموعات مباشرة
                    await self.send_groups_keyboard(update, context, db_groups)
                else:
                    await context.bot.send_message(
                        chat_id=update.effective_chat.id,
                        text="⚠️ لم يتم العثور على مجموعات."
                    )
            else:
                # Update message with error
                await query.edit_message_text(
                    text=f"❌ {result_message}"
                )
        
        elif data.startswith("group_toggle_"):
            # Toggle group blacklist status
            try:
                # استخراج معرف المجموعة من البيانات
                group_id_str = data.split("group_toggle_")[1]
                # تحسين: التحقق من أن group_id_str ليس None قبل محاولة التحويل
                if group_id_str and group_id_str.lower() != 'none':
                    group_id = str(group_id_str)  # تحويل معرف المجموعة إلى نص
                else:
                    self.logger.error(f"Invalid group_id: {group_id_str}, data: {data}")
                    await query.edit_message_text(
                        text="❌ معرف المجموعة غير صالح. يرجى تحديث المجموعات والمحاولة مرة أخرى."
                    )
                    return
            except (ValueError, IndexError) as e:
                self.logger.error(f"Error parsing group_id: {str(e)}, data: {data}")
                await query.edit_message_text(
                    text="❌ حدث خطأ في معرف المجموعة. يرجى تحديث المجموعات والمحاولة مرة أخرى."
                )
                return
            
            # Toggle blacklist status
            success, is_blacklisted = self.group_service.toggle_group_blacklist(user_id, group_id)
            
            if success:
                # Get updated groups
                groups = self.group_service.get_user_groups(user_id)
                
                # Update keyboard
                await self.update_groups_keyboard(query, groups)
            else:
                await query.edit_message_text(
                    text="❌ حدث خطأ أثناء تحديث حالة المجموعة."
                )
        
        elif data == "group_done":
            # User is done with group selection
            active_groups = self.group_service.get_user_active_groups(user_id)
            
            await query.edit_message_text(
                text=f"✅ تم حفظ إعدادات المجموعات بنجاح.\n\n"
                     f"👥 المجموعات النشطة: {len(active_groups)}\n\n"
                     f"استخدم /groups في أي وقت لإدارة المجموعات."
            )
        
        elif data == "group_select_all":
            # تحديد كل المجموعات أو إلغاء تحديد الكل
            groups = self.group_service.get_user_groups(user_id)
            
            # تحقق مما إذا كانت جميع المجموعات في القائمة السوداء بالفعل
            all_blacklisted = all(group.get('blacklisted', False) for group in groups)
            
            # إذا كانت جميع المجموعات في القائمة السوداء، قم بإزالتها جميعًا
            # وإلا، أضف جميع المجموعات إلى القائمة السوداء
            for group in groups:
                group_id = str(group.get('group_id'))
                if group_id:
                    if all_blacklisted:
                        # إزالة من القائمة السوداء
                        if group.get('blacklisted', False):
                            self.group_service.toggle_group_blacklist(user_id, group_id)
                    else:
                        # إضافة إلى القائمة السوداء
                        if not group.get('blacklisted', False):
                            self.group_service.toggle_group_blacklist(user_id, group_id)
            
            # الحصول على المجموعات المحدثة
            updated_groups = self.group_service.get_user_groups(user_id)
            
            # تحديث لوحة المفاتيح
            await self.update_groups_keyboard(query, updated_groups)
    
    async def send_groups_keyboard(self, update, context, groups):
        """Send keyboard with groups for management"""
        chat_id = update.effective_chat.id
        
        # Create message text
        message_text = "👥 إدارة المجموعات:\n\n"
        message_text += "اضغط على أي مجموعة لإضافتها أو إزالتها من القائمة السوداء.\n"
        message_text += "🔵 = مجموعة نشطة\n"
        message_text += "⚪ = مجموعة في القائمة السوداء (لن يتم النشر فيها)\n\n"
        
        # Create keyboard with groups
        keyboard = []
        row = []
        
        for i, group in enumerate(groups):
            # Determine emoji based on blacklist status
            emoji = "⚪" if group.get('blacklisted', False) else "🔵"
            
            # تحسين: التأكد من أن group_id ليس None وتحويله إلى نص
            group_id = group.get('group_id')
            if group_id is None:
                self.logger.warning(f"Group without ID found: {group}")
                continue
                
            # Create button
            button = InlineKeyboardButton(
                f"{emoji} {group.get('title', 'مجموعة')}",
                callback_data=f"group_toggle_{group_id}"
            )
            
            # Add button to row
            row.append(button)
            
            # Create new row every 1 button (one column layout)
            if len(row) == 1:
                keyboard.append(row)
                row = []
        
        # Add any remaining buttons
        if row:
            keyboard.append(row)
        
        # إضافة زر تحديد الكل
        keyboard.append([InlineKeyboardButton("🔵 تحديد/إلغاء تحديد الكل", callback_data="group_select_all")])
        
        # Add done button
        keyboard.append([InlineKeyboardButton("✅ تم", callback_data="group_done")])
        
        # تغيير لون زر التحديث من أزرق إلى أحمر وأخضر
        keyboard.append([InlineKeyboardButton("🔴 🟢 تحديث المجموعات", callback_data="group_refresh")])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await context.bot.send_message(
            chat_id=chat_id,
            text=message_text,
            reply_markup=reply_markup
        )
    
    async def update_groups_keyboard(self, query, groups):
        """Update existing keyboard with updated group status"""
        # Create message text
        message_text = "👥 إدارة المجموعات:\n\n"
        message_text += "اضغط على أي مجموعة لإضافتها أو إزالتها من القائمة السوداء.\n"
        message_text += "🔵 = مجموعة نشطة\n"
        message_text += "⚪ = مجموعة في القائمة السوداء (لن يتم النشر فيها)\n\n"
        
        # Create keyboard with groups
        keyboard = []
        row = []
        
        for i, group in enumerate(groups):
            # Determine emoji based on blacklist status
            emoji = "⚪" if group.get('blacklisted', False) else "🔵"
            
            # تحسين: التأكد من أن group_id ليس None وتحويله إلى نص
            group_id = group.get('group_id')
            if group_id is None:
                self.logger.warning(f"Group without ID found: {group}")
                continue
                
            # Create button
            button = InlineKeyboardButton(
                f"{emoji} {group.get('title', 'مجموعة')}",
                callback_data=f"group_toggle_{group_id}"
            )
            
            # Add button to row
            row.append(button)
            
            # Create new row every 1 button (one column layout)
            if len(row) == 1:
                keyboard.append(row)
                row = []
        
        # Add any remaining buttons
        if row:
            keyboard.append(row)
        
        # إضافة زر تحديد الكل
        keyboard.append([InlineKeyboardButton("🔵 تحديد/إلغاء تحديد الكل", callback_data="group_select_all")])
        
        # Add done button
        keyboard.append([InlineKeyboardButton("✅ تم", callback_data="group_done")])
        
        # تغيير لون زر التحديث من أزرق إلى أحمر وأخضر
        keyboard.append([InlineKeyboardButton("🔴 🟢 تحديث المجموعات", callback_data="group_refresh")])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            text=message_text,
            reply_markup=reply_markup
        )
