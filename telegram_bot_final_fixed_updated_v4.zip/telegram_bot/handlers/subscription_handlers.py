from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import CallbackContext, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ConversationHandler
from services.subscription_service import SubscriptionService
from config.config import ADMIN_USER_ID
from utils.decorators import admin_only, subscription_required
from utils.channel_subscription import channel_subscription, auto_channel_subscription_required
import re
import logging

# إعداد التسجيل
logger = logging.getLogger(__name__)

# حالات المحادثة
WAITING_FOR_CHANNEL = 1

class SubscriptionHandlers:
    def __init__(self, dispatcher):
        self.dispatcher = dispatcher
        self.subscription_service = SubscriptionService()
        
        # Register handlers
        self.register_handlers()
    
    def register_handlers(self):
        # Admin commands
        self.dispatcher.add_handler(CommandHandler("adduser", self.add_user_command))
        self.dispatcher.add_handler(CommandHandler("removeuser", self.remove_user_command))
        self.dispatcher.add_handler(CommandHandler("checkuser", self.check_user_command))
        self.dispatcher.add_handler(CommandHandler("listusers", self.list_users_command))
        
        # Channel subscription command - simplified to one command
        channel_conv_handler = ConversationHandler(
            entry_points=[
                CommandHandler("channel_subscription", self.channel_subscription_command),
                CommandHandler("set_subscription", self.channel_subscription_command),
                CommandHandler("setchannel", self.channel_subscription_command)
            ],
            states={
                WAITING_FOR_CHANNEL: [MessageHandler(filters.TEXT & ~filters.COMMAND, self.process_channel_username)]
            },
            fallbacks=[CommandHandler("cancel", self.cancel_handler)]
        )
        self.dispatcher.add_handler(channel_conv_handler)
        
        # User commands
        self.dispatcher.add_handler(CommandHandler("subscription", self.subscription_status_command))
        
        # Callback queries
        self.dispatcher.add_handler(CallbackQueryHandler(self.subscription_callback, pattern='^subscription_'))
    
    @admin_only
    async def channel_subscription_command(self, update: Update, context: CallbackContext):
        """Start the process of setting up mandatory channel subscription"""
        chat_id = update.effective_chat.id
        
        # إذا تم تقديم معرف القناة كمعلمة، استخدمه مباشرة
        if context.args:
            channel_username = context.args[0]
            # حفظ معرف القناة في بيانات المستخدم
            context.user_data['channel_username'] = channel_username
            # معالجة معرف القناة
            return await self.process_channel_username(update, context)
        
        # طلب معرف القناة من المستخدم
        await context.bot.send_message(
            chat_id=chat_id,
            text="🔧 إعداد الاشتراك الإجباري في القناة\n\n"
                 "يرجى إدخال معرف القناة (مثال: @channel_name):\n\n"
                 "ملاحظة: يجب أن يكون البوت مشرفاً في القناة لتفعيل الاشتراك الإجباري."
        )
        
        return WAITING_FOR_CHANNEL
    
    async def process_channel_username(self, update: Update, context: CallbackContext):
        """Process the channel username provided by the user"""
        chat_id = update.effective_chat.id
        
        # الحصول على معرف القناة من الرسالة أو من بيانات المستخدم
        if 'channel_username' in context.user_data:
            channel_username = context.user_data['channel_username']
            del context.user_data['channel_username']  # مسح البيانات بعد استخدامها
        else:
            channel_username = update.message.text.strip()
        
        try:
            # التأكد من أن معرف القناة يبدأ بـ @
            if not channel_username.startswith('@'):
                channel_username = f"@{channel_username}"
            
            # إرسال رسالة "جاري التحقق"
            status_message = await context.bot.send_message(
                chat_id=chat_id,
                text="⏳ جاري التحقق من صلاحيات البوت في القناة..."
            )
            
            # التحقق من أن البوت مشرف في القناة
            channel_subscription.set_required_channel(channel_username)  # تعيين القناة مؤقتاً للتحقق
            is_admin, error_message = await channel_subscription.check_bot_is_admin(context.bot)
            
            if not is_admin:
                await context.bot.edit_message_text(
                    chat_id=chat_id,
                    message_id=status_message.message_id,
                    text=f"❌ {error_message}\n\n"
                         f"يجب أن يكون البوت مشرفاً في القناة {channel_username} لتفعيل الاشتراك الإجباري.\n\n"
                         f"الرجاء إضافة البوت كمشرف في القناة ثم إعادة المحاولة باستخدام الأمر /channel_subscription"
                )
                channel_subscription.set_required_channel(None)  # إعادة تعيين القناة إلى لا شيء
                return ConversationHandler.END
            
            # تعيين القناة المطلوبة للاشتراك
            channel_subscription.set_required_channel(channel_username)
            
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=status_message.message_id,
                text=f"✅ تم تعيين القناة المطلوبة للاشتراك: {channel_subscription.get_required_channel()}\n\n"
                     f"سيطلب البوت من المستخدمين الاشتراك في هذه القناة قبل استخدام البوت.\n\n"
                     f"سيتم التحقق تلقائياً من اشتراك المستخدمين في القناة عند كل استخدام للبوت."
            )
            
            return ConversationHandler.END
            
        except ValueError as e:
            await context.bot.send_message(
                chat_id=chat_id,
                text=f"❌ {str(e)}\n\nالرجاء إدخال معرف قناة صالح."
            )
            return WAITING_FOR_CHANNEL
            
        except Exception as e:
            logger.error(f"خطأ في تعيين قناة الاشتراك الإجباري: {str(e)}")
            await context.bot.send_message(
                chat_id=chat_id,
                text=f"❌ حدث خطأ: {str(e)}\n\nالرجاء المحاولة مرة أخرى."
            )
            return ConversationHandler.END
    
    async def cancel_handler(self, update: Update, context: CallbackContext):
        """Cancel the conversation"""
        chat_id = update.effective_chat.id
        
        await context.bot.send_message(
            chat_id=chat_id,
            text="❌ تم إلغاء العملية."
        )
        
        return ConversationHandler.END
    
    @admin_only
    @auto_channel_subscription_required
    async def add_user_command(self, update: Update, context: CallbackContext):
        """Add a user to subscription list. Format: /adduser USER_ID DAYS"""
        chat_id = update.effective_chat.id
        
        if not context.args or len(context.args) < 2:
            await context.bot.send_message(
                chat_id=chat_id,
                text="⚠️ الصيغة غير صحيحة. الرجاء استخدام: /adduser USER_ID DAYS"
            )
            return
        
        try:
            user_id = int(context.args[0])
            days = int(context.args[1])
            
            if days <= 0:
                await context.bot.send_message(
                    chat_id=chat_id,
                    text="⚠️ يجب أن يكون عدد الأيام أكبر من صفر."
                )
                return
            
            # Get or create user
            user = self.subscription_service.get_user(user_id)
            if not user:
                user = self.subscription_service.create_user(user_id)
            
            # Add subscription
            success = self.subscription_service.add_subscription(user_id, days, added_by=update.effective_user.id)
            
            if success:
                end_date = self.subscription_service.get_subscription_end_date(user_id)
                # Fix: Check if end_date is None before calling strftime
                end_date_str = end_date.strftime('%Y-%m-%d %H:%M:%S') if end_date else "غير محدد"
                await context.bot.send_message(
                    chat_id=chat_id,
                    text=f"✅ تم إضافة اشتراك للمستخدم {user_id} لمدة {days} يوم.\n"
                         f"تاريخ انتهاء الاشتراك: {end_date_str}"
                )
                
                # Notify user about subscription
                try:
                    # Fix: Check if end_date is None before calling strftime
                    end_date_str = end_date.strftime('%Y-%m-%d %H:%M:%S') if end_date else "غير محدد"
                    
                    # التحقق من اشتراك المستخدم في القناة الإجبارية
                    required_channel = channel_subscription.get_required_channel()
                    subscription_message = f"🎉 مبروك! تم تفعيل اشتراكك لمدة {days} يوم.\n" \
                                          f"تاريخ انتهاء الاشتراك: {end_date_str}"
                    
                    if required_channel:
                        is_subscribed, _ = await channel_subscription.check_user_subscription(context.bot, user_id)
                        if not is_subscribed:
                            # إضافة تنبيه بضرورة الاشتراك في القناة
                            keyboard = [
                                [InlineKeyboardButton("✅ اشترك في القناة", url=f"https://t.me/{required_channel[1:]}")],
                            ]
                            reply_markup = InlineKeyboardMarkup(keyboard)
                            
                            subscription_message += f"\n\n⚠️ ملاحظة: يجب عليك الاشتراك في القناة {required_channel} للاستمرار في استخدام البوت."
                            
                            await context.bot.send_message(
                                chat_id=user_id,
                                text=subscription_message,
                                reply_markup=reply_markup
                            )
                        else:
                            await context.bot.send_message(
                                chat_id=user_id,
                                text=subscription_message
                            )
                    else:
                        await context.bot.send_message(
                            chat_id=user_id,
                            text=subscription_message
                        )
                except Exception as e:
                    logger.error(f"خطأ في إرسال إشعار للمستخدم {user_id}: {str(e)}")
                    await context.bot.send_message(
                        chat_id=chat_id,
                        text=f"⚠️ تم إضافة الاشتراك ولكن لم نتمكن من إرسال إشعار للمستخدم: {str(e)}"
                    )
            else:
                await context.bot.send_message(
                    chat_id=chat_id,
                    text=f"❌ فشل في إضافة اشتراك للمستخدم {user_id}."
                )
        except ValueError:
            await context.bot.send_message(
                chat_id=chat_id,
                text="⚠️ الصيغة غير صحيحة. الرجاء استخدام: /adduser USER_ID DAYS"
            )
        except Exception as e:
            logger.error(f"خطأ في إضافة اشتراك للمستخدم: {str(e)}")
            await context.bot.send_message(
                chat_id=chat_id,
                text=f"❌ حدث خطأ: {str(e)}"
            )
    
    @admin_only
    @auto_channel_subscription_required
    async def remove_user_command(self, update: Update, context: CallbackContext):
        """Remove a user's subscription. Format: /removeuser USER_ID"""
        chat_id = update.effective_chat.id
        
        if not context.args:
            await context.bot.send_message(
                chat_id=chat_id,
                text="⚠️ الصيغة غير صحيحة. الرجاء استخدام: /removeuser USER_ID"
            )
            return
        
        try:
            user_id = int(context.args[0])
            
            # Get user
            user = self.subscription_service.get_user(user_id)
            if not user:
                await context.bot.send_message(
                    chat_id=chat_id,
                    text=f"❌ المستخدم {user_id} غير موجود."
                )
                return
            
            # Remove subscription
            user.subscription_end = None
            self.subscription_service.save_user(user)
            
            await context.bot.send_message(
                chat_id=chat_id,
                text=f"✅ تم إلغاء اشتراك المستخدم {user_id} بنجاح."
            )
            
            # Notify user about subscription removal
            try:
                await context.bot.send_message(
                    chat_id=user_id,
                    text="⚠️ تم إلغاء اشتراكك. الرجاء التواصل مع المسؤول لتجديد الاشتراك."
                )
            except Exception as e:
                logger.error(f"خطأ في إرسال إشعار إلغاء الاشتراك للمستخدم {user_id}: {str(e)}")
            
        except ValueError:
            await context.bot.send_message(
                chat_id=chat_id,
                text="⚠️ الصيغة غير صحيحة. الرجاء استخدام: /removeuser USER_ID"
            )
        except Exception as e:
            logger.error(f"خطأ في إلغاء اشتراك المستخدم: {str(e)}")
            await context.bot.send_message(
                chat_id=chat_id,
                text=f"❌ حدث خطأ: {str(e)}"
            )
    
    @admin_only
    @auto_channel_subscription_required
    async def check_user_command(self, update: Update, context: CallbackContext):
        """Check a user's subscription status. Format: /checkuser USER_ID"""
        chat_id = update.effective_chat.id
        
        if not context.args:
            await context.bot.send_message(
                chat_id=chat_id,
                text="⚠️ الصيغة غير صحيحة. الرجاء استخدام: /checkuser USER_ID"
            )
            return
        
        try:
            user_id = int(context.args[0])
            
            # Get user
            user = self.subscription_service.get_user(user_id)
            if not user:
                await context.bot.send_message(
                    chat_id=chat_id,
                    text=f"❌ المستخدم {user_id} غير موجود."
                )
                return
            
            # Check subscription
            has_subscription = user.has_active_subscription()
            end_date = user.subscription_end
            
            # التحقق من اشتراك المستخدم في القناة الإجبارية
            required_channel = channel_subscription.get_required_channel()
            channel_status = "غير مطلوب"
            
            if required_channel:
                is_subscribed, _ = await channel_subscription.check_user_subscription(context.bot, user_id)
                channel_status = f"✅ مشترك في {required_channel}" if is_subscribed else f"❌ غير مشترك في {required_channel}"
            
            if has_subscription:
                # Fix: Check if end_date is None before calling strftime
                end_date_str = end_date.strftime('%Y-%m-%d %H:%M:%S') if end_date else "غير محدد"
                await context.bot.send_message(
                    chat_id=chat_id,
                    text=f"✅ المستخدم {user_id} لديه اشتراك نشط.\n"
                         f"تاريخ انتهاء الاشتراك: {end_date_str}\n"
                         f"حالة اشتراك القناة: {channel_status}"
                )
            else:
                await context.bot.send_message(
                    chat_id=chat_id,
                    text=f"❌ المستخدم {user_id} ليس لديه اشتراك نشط.\n"
                         f"حالة اشتراك القناة: {channel_status}"
                )
            
        except ValueError:
            await context.bot.send_message(
                chat_id=chat_id,
                text="⚠️ الصيغة غير صحيحة. الرجاء استخدام: /checkuser USER_ID"
            )
        except Exception as e:
            logger.error(f"خطأ في التحقق من حالة اشتراك المستخدم: {str(e)}")
            await context.bot.send_message(
                chat_id=chat_id,
                text=f"❌ حدث خطأ: {str(e)}"
            )
    
    @admin_only
    @auto_channel_subscription_required
    async def list_users_command(self, update: Update, context: CallbackContext):
        """List all users with active subscriptions"""
        chat_id = update.effective_chat.id
        
        try:
            # Get all subscribers
            subscribers = self.subscription_service.get_all_subscribers()
            
            if not subscribers:
                await context.bot.send_message(
                    chat_id=chat_id,
                    text="❌ لا يوجد مستخدمين لديهم اشتراكات نشطة."
                )
                return
            
            # Format message
            message = "📋 قائمة المستخدمين مع اشتراكات نشطة:\n\n"
            for user in subscribers:
                username = f"@{user.username}" if user.username else "غير معروف"
                name = f"{user.first_name} {user.last_name or ''}" if user.first_name else "غير معروف"
                # Fix: Check if subscription_end is None before calling strftime
                end_date = user.subscription_end.strftime('%Y-%m-%d') if user.subscription_end else "غير محدد"
                
                # التحقق من اشتراك المستخدم في القناة الإجبارية
                required_channel = channel_subscription.get_required_channel()
                channel_status = "غير مطلوب"
                
                if required_channel:
                    is_subscribed, _ = await channel_subscription.check_user_subscription(context.bot, user.user_id)
                    channel_status = f"✅ مشترك في القناة" if is_subscribed else f"❌ غير مشترك في القناة"
                
                message += f"🔹 المعرف: {user.user_id}\n"
                message += f"👤 المستخدم: {username}\n"
                message += f"📝 الاسم: {name}\n"
                message += f"📅 تاريخ انتهاء الاشتراك: {end_date}\n"
                message += f"📢 حالة اشتراك القناة: {channel_status}\n\n"
            
            # Send message in chunks if too long
            if len(message) > 4000:
                chunks = [message[i:i+4000] for i in range(0, len(message), 4000)]
                for chunk in chunks:
                    await context.bot.send_message(
                        chat_id=chat_id,
                        text=chunk
                    )
            else:
                await context.bot.send_message(
                    chat_id=chat_id,
                    text=message
                )
            
        except Exception as e:
            logger.error(f"خطأ في عرض قائمة المستخدمين: {str(e)}")
            await context.bot.send_message(
                chat_id=chat_id,
                text=f"❌ حدث خطأ: {str(e)}"
            )
    
    @auto_channel_subscription_required
    async def subscription_status_command(self, update: Update, context: CallbackContext):
        """Check your subscription status"""
        chat_id = update.effective_chat.id
        user_id = update.effective_user.id
        
        try:
            # Get user
            user = self.subscription_service.get_user(user_id)
            if not user:
                user = self.subscription_service.create_user(
                    user_id, 
                    update.effective_user.username,
                    update.effective_user.first_name,
                    update.effective_user.last_name
                )
            
            # Check subscription
            has_subscription = user.has_active_subscription()
            
            # التحقق من اشتراك المستخدم في القناة الإجبارية
            required_channel = channel_subscription.get_required_channel()
            
            if has_subscription:
                end_date = user.subscription_end
                # Fix: Check if end_date is None before calling strftime
                end_date_str = end_date.strftime('%Y-%m-%d %H:%M:%S') if end_date else "غير محدد"
                
                if required_channel:
                    is_subscribed, _ = await channel_subscription.check_user_subscription(context.bot, user_id)
                    
                    if is_subscribed:
                        await context.bot.send_message(
                            chat_id=chat_id,
                            text=f"✅ لديك اشتراك نشط.\n"
                                 f"تاريخ انتهاء الاشتراك: {end_date_str}\n"
                                 f"✅ أنت مشترك في القناة {required_channel}"
                        )
                    else:
                        # المستخدم غير مشترك في القناة، عرض رسالة الاشتراك
                        keyboard = [
                            [InlineKeyboardButton("✅ اشترك في القناة", url=f"https://t.me/{required_channel[1:]}")],
                        ]
                        reply_markup = InlineKeyboardMarkup(keyboard)
                        
                        await context.bot.send_message(
                            chat_id=chat_id,
                            text=f"✅ لديك اشتراك نشط.\n"
                                 f"تاريخ انتهاء الاشتراك: {end_date_str}\n\n"
                                 f"⚠️ لكن يجب عليك الاشتراك في القناة {required_channel} للاستمرار في استخدام البوت.",
                            reply_markup=reply_markup
                        )
                else:
                    await context.bot.send_message(
                        chat_id=chat_id,
                        text=f"✅ لديك اشتراك نشط.\n"
                             f"تاريخ انتهاء الاشتراك: {end_date_str}"
                    )
            else:
                # Create subscription request button
                keyboard = [
                    [InlineKeyboardButton("🔔 طلب اشتراك", callback_data="subscription_request")]
                ]
                
                if required_channel:
                    keyboard.append([InlineKeyboardButton("✅ اشترك في القناة", url=f"https://t.me/{required_channel[1:]}")])
                
                reply_markup = InlineKeyboardMarkup(keyboard)
                
                message_text = "❌ ليس لديك اشتراك نشط. يرجى طلب اشتراك للاستمرار في استخدام البوت."
                
                if required_channel:
                    message_text += f"\n\n⚠️ كما يجب عليك الاشتراك في القناة {required_channel} للاستمرار في استخدام البوت."
                
                await context.bot.send_message(
                    chat_id=chat_id,
                    text=message_text,
                    reply_markup=reply_markup
                )
            
        except Exception as e:
            logger.error(f"خطأ في التحقق من حالة الاشتراك: {str(e)}")
            await context.bot.send_message(
                chat_id=chat_id,
                text=f"❌ حدث خطأ: {str(e)}"
            )
    
    @auto_channel_subscription_required
    async def subscription_callback(self, update: Update, context: CallbackContext):
        """Handle subscription-related callbacks"""
        query = update.callback_query
        await query.answer()
        
        if query.data == "subscription_request":
            admin_username = "S_S_0_c"  # تحديث اسم المستخدم للمسؤول
            
            # Send message to user
            await query.edit_message_text(
                text=f"📨 تم إرسال طلب الاشتراك إلى المسؤول. سيتم التواصل معك قريباً.\n\n"
                     f"يمكنك التواصل مباشرة مع @{admin_username} لتفعيل اشتراكك."
            )
            
            # Notify admin
            try:
                user = update.effective_user
                user_id = user.id
                username = f"@{user.username}" if user.username else "غير متوفر"
                name = f"{user.first_name} {user.last_name or ''}" if user.first_name else "غير متوفر"
                
                admin_message = f"🔔 طلب اشتراك جديد:\n\n"
                admin_message += f"🆔 المعرف: {user_id}\n"
                admin_message += f"👤 المستخدم: {username}\n"
                admin_message += f"📝 الاسم: {name}\n\n"
                admin_message += f"لتفعيل الاشتراك، استخدم الأمر:\n/adduser {user_id} 30"
                
                # Get admin user ID from config
                admin_id = ADMIN_USER_ID
                
                if admin_id:
                    await context.bot.send_message(
                        chat_id=admin_id,
                        text=admin_message
                    )
            except Exception as e:
                logger.error(f"خطأ في إرسال إشعار طلب الاشتراك للمسؤول: {str(e)}")
